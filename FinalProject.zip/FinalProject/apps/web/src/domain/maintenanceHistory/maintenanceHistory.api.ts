import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { MaintenanceHistory } from './maintenanceHistory.model'

export class MaintenanceHistoryApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<MaintenanceHistory>,
  ): Promise<MaintenanceHistory[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/maintenanceHistorys${buildOptions}`)
  }

  static findOne(
    maintenanceHistoryId: string,
    queryOptions?: ApiHelper.QueryOptions<MaintenanceHistory>,
  ): Promise<MaintenanceHistory> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/maintenanceHistorys/${maintenanceHistoryId}${buildOptions}`,
    )
  }

  static createOne(
    values: Partial<MaintenanceHistory>,
  ): Promise<MaintenanceHistory> {
    return HttpService.api.post(`/v1/maintenanceHistorys`, values)
  }

  static updateOne(
    maintenanceHistoryId: string,
    values: Partial<MaintenanceHistory>,
  ): Promise<MaintenanceHistory> {
    return HttpService.api.patch(
      `/v1/maintenanceHistorys/${maintenanceHistoryId}`,
      values,
    )
  }

  static deleteOne(maintenanceHistoryId: string): Promise<void> {
    return HttpService.api.delete(
      `/v1/maintenanceHistorys/${maintenanceHistoryId}`,
    )
  }

  static findManyByVehicleId(
    vehicleId: string,
    queryOptions?: ApiHelper.QueryOptions<MaintenanceHistory>,
  ): Promise<MaintenanceHistory[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/vehicles/vehicle/${vehicleId}/maintenanceHistorys${buildOptions}`,
    )
  }

  static createOneByVehicleId(
    vehicleId: string,
    values: Partial<MaintenanceHistory>,
  ): Promise<MaintenanceHistory> {
    return HttpService.api.post(
      `/v1/vehicles/vehicle/${vehicleId}/maintenanceHistorys`,
      values,
    )
  }

  static findManyByTaskId(
    taskId: string,
    queryOptions?: ApiHelper.QueryOptions<MaintenanceHistory>,
  ): Promise<MaintenanceHistory[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/maintenanceTasks/task/${taskId}/maintenanceHistorys${buildOptions}`,
    )
  }

  static createOneByTaskId(
    taskId: string,
    values: Partial<MaintenanceHistory>,
  ): Promise<MaintenanceHistory> {
    return HttpService.api.post(
      `/v1/maintenanceTasks/task/${taskId}/maintenanceHistorys`,
      values,
    )
  }
}
