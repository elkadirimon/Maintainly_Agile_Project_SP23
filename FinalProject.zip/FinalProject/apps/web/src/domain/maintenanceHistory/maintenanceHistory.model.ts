import { Vehicle } from '../vehicle'

import { MaintenanceTask } from '../maintenanceTask'

export class MaintenanceHistory {
  id: string

  completionDate: string

  details: string

  vehicleId: string

  vehicle?: Vehicle

  taskId: string

  task?: MaintenanceTask

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
