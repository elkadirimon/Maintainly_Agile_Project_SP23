import { AiApi } from './ai/ai.api'
import { AuthenticationApi } from './authentication/authentication.api'
import { AuthorizationApi } from './authorization/authorization.api'
import { UploadApi } from './upload/upload.api'

import { UserApi } from './user/user.api'

import { NotificationApi } from './notification/notification.api'

import { VehicleApi } from './vehicle/vehicle.api'

import { MaintenanceTaskApi } from './maintenanceTask/maintenanceTask.api'

import { ServiceMilestoneApi } from './serviceMilestone/serviceMilestone.api'

import { FuelRecordApi } from './fuelRecord/fuelRecord.api'

import { MaintenanceHistoryApi } from './maintenanceHistory/maintenanceHistory.api'

import { EventApi } from './event/event.api'

import { VehicleEventApi } from './vehicleEvent/vehicleEvent.api'

import { ServiceRecommendationApi } from './serviceRecommendation/serviceRecommendation.api'

export namespace Api {
  export class Ai extends AiApi {}
  export class Authentication extends AuthenticationApi {}
  export class Authorization extends AuthorizationApi {}
  export class Upload extends UploadApi {}

  export class User extends UserApi {}

  export class Notification extends NotificationApi {}

  export class Vehicle extends VehicleApi {}

  export class MaintenanceTask extends MaintenanceTaskApi {}

  export class ServiceMilestone extends ServiceMilestoneApi {}

  export class FuelRecord extends FuelRecordApi {}

  export class MaintenanceHistory extends MaintenanceHistoryApi {}

  export class Event extends EventApi {}

  export class VehicleEvent extends VehicleEventApi {}

  export class ServiceRecommendation extends ServiceRecommendationApi {}
}
