import { VehicleEvent } from '../vehicleEvent'

export class Event {
  id: string

  description: string

  startTime: string

  endTime: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  vehicleEvents?: VehicleEvent[]
}
