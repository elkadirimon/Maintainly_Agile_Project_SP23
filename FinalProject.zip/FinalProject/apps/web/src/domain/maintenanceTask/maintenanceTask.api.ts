import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { MaintenanceTask } from './maintenanceTask.model'

export class MaintenanceTaskApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<MaintenanceTask>,
  ): Promise<MaintenanceTask[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/maintenanceTasks${buildOptions}`)
  }

  static findOne(
    maintenanceTaskId: string,
    queryOptions?: ApiHelper.QueryOptions<MaintenanceTask>,
  ): Promise<MaintenanceTask> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/maintenanceTasks/${maintenanceTaskId}${buildOptions}`,
    )
  }

  static createOne(values: Partial<MaintenanceTask>): Promise<MaintenanceTask> {
    return HttpService.api.post(`/v1/maintenanceTasks`, values)
  }

  static updateOne(
    maintenanceTaskId: string,
    values: Partial<MaintenanceTask>,
  ): Promise<MaintenanceTask> {
    return HttpService.api.patch(
      `/v1/maintenanceTasks/${maintenanceTaskId}`,
      values,
    )
  }

  static deleteOne(maintenanceTaskId: string): Promise<void> {
    return HttpService.api.delete(`/v1/maintenanceTasks/${maintenanceTaskId}`)
  }

  static findManyByVehicleId(
    vehicleId: string,
    queryOptions?: ApiHelper.QueryOptions<MaintenanceTask>,
  ): Promise<MaintenanceTask[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/vehicles/vehicle/${vehicleId}/maintenanceTasks${buildOptions}`,
    )
  }

  static createOneByVehicleId(
    vehicleId: string,
    values: Partial<MaintenanceTask>,
  ): Promise<MaintenanceTask> {
    return HttpService.api.post(
      `/v1/vehicles/vehicle/${vehicleId}/maintenanceTasks`,
      values,
    )
  }
}
