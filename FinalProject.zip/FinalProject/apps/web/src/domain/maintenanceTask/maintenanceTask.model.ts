import { Vehicle } from '../vehicle'

import { MaintenanceHistory } from '../maintenanceHistory'

export class MaintenanceTask {
  id: string

  description: string

  dueDate: string

  status: string

  vehicleId: string

  vehicle?: Vehicle

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  maintenanceHistorysAsTask?: MaintenanceHistory[]
}
