import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { FuelRecord } from './fuelRecord.model'

export class FuelRecordApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<FuelRecord>,
  ): Promise<FuelRecord[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/fuelRecords${buildOptions}`)
  }

  static findOne(
    fuelRecordId: string,
    queryOptions?: ApiHelper.QueryOptions<FuelRecord>,
  ): Promise<FuelRecord> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/fuelRecords/${fuelRecordId}${buildOptions}`)
  }

  static createOne(values: Partial<FuelRecord>): Promise<FuelRecord> {
    return HttpService.api.post(`/v1/fuelRecords`, values)
  }

  static updateOne(
    fuelRecordId: string,
    values: Partial<FuelRecord>,
  ): Promise<FuelRecord> {
    return HttpService.api.patch(`/v1/fuelRecords/${fuelRecordId}`, values)
  }

  static deleteOne(fuelRecordId: string): Promise<void> {
    return HttpService.api.delete(`/v1/fuelRecords/${fuelRecordId}`)
  }

  static findManyByVehicleId(
    vehicleId: string,
    queryOptions?: ApiHelper.QueryOptions<FuelRecord>,
  ): Promise<FuelRecord[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/vehicles/vehicle/${vehicleId}/fuelRecords${buildOptions}`,
    )
  }

  static createOneByVehicleId(
    vehicleId: string,
    values: Partial<FuelRecord>,
  ): Promise<FuelRecord> {
    return HttpService.api.post(
      `/v1/vehicles/vehicle/${vehicleId}/fuelRecords`,
      values,
    )
  }
}
