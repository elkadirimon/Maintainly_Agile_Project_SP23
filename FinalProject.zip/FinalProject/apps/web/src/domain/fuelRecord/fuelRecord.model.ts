import { Vehicle } from '../vehicle'

export class FuelRecord {
  id: string

  date: string

  fuelVolume: number

  vehicleId: string

  vehicle?: Vehicle

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
