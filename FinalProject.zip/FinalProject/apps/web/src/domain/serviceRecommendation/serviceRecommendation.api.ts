import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { ServiceRecommendation } from './serviceRecommendation.model'

export class ServiceRecommendationApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<ServiceRecommendation>,
  ): Promise<ServiceRecommendation[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/serviceRecommendations${buildOptions}`)
  }

  static findOne(
    serviceRecommendationId: string,
    queryOptions?: ApiHelper.QueryOptions<ServiceRecommendation>,
  ): Promise<ServiceRecommendation> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/serviceRecommendations/${serviceRecommendationId}${buildOptions}`,
    )
  }

  static createOne(
    values: Partial<ServiceRecommendation>,
  ): Promise<ServiceRecommendation> {
    return HttpService.api.post(`/v1/serviceRecommendations`, values)
  }

  static updateOne(
    serviceRecommendationId: string,
    values: Partial<ServiceRecommendation>,
  ): Promise<ServiceRecommendation> {
    return HttpService.api.patch(
      `/v1/serviceRecommendations/${serviceRecommendationId}`,
      values,
    )
  }

  static deleteOne(serviceRecommendationId: string): Promise<void> {
    return HttpService.api.delete(
      `/v1/serviceRecommendations/${serviceRecommendationId}`,
    )
  }

  static findManyByVehicleId(
    vehicleId: string,
    queryOptions?: ApiHelper.QueryOptions<ServiceRecommendation>,
  ): Promise<ServiceRecommendation[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/vehicles/vehicle/${vehicleId}/serviceRecommendations${buildOptions}`,
    )
  }

  static createOneByVehicleId(
    vehicleId: string,
    values: Partial<ServiceRecommendation>,
  ): Promise<ServiceRecommendation> {
    return HttpService.api.post(
      `/v1/vehicles/vehicle/${vehicleId}/serviceRecommendations`,
      values,
    )
  }
}
