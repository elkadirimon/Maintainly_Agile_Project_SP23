import { Vehicle } from '../vehicle'

export class ServiceRecommendation {
  id: string

  lastServiceDate: string

  recommendedServiceDate: string

  vehicleId: string

  vehicle?: Vehicle

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
