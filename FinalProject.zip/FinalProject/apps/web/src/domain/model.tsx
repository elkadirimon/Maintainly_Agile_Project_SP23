import { AuthorizationRole as AuthorizationRoleModel } from './authorization/authorization.model'

import { User as UserModel } from './user/user.model'

import { Notification as NotificationModel } from './notification/notification.model'

import { Vehicle as VehicleModel } from './vehicle/vehicle.model'

import { MaintenanceTask as MaintenanceTaskModel } from './maintenanceTask/maintenanceTask.model'

import { ServiceMilestone as ServiceMilestoneModel } from './serviceMilestone/serviceMilestone.model'

import { FuelRecord as FuelRecordModel } from './fuelRecord/fuelRecord.model'

import { MaintenanceHistory as MaintenanceHistoryModel } from './maintenanceHistory/maintenanceHistory.model'

import { Event as EventModel } from './event/event.model'

import { VehicleEvent as VehicleEventModel } from './vehicleEvent/vehicleEvent.model'

import { ServiceRecommendation as ServiceRecommendationModel } from './serviceRecommendation/serviceRecommendation.model'

export namespace Model {
  export class AuthorizationRole extends AuthorizationRoleModel {}

  export class User extends UserModel {}

  export class Notification extends NotificationModel {}

  export class Vehicle extends VehicleModel {}

  export class MaintenanceTask extends MaintenanceTaskModel {}

  export class ServiceMilestone extends ServiceMilestoneModel {}

  export class FuelRecord extends FuelRecordModel {}

  export class MaintenanceHistory extends MaintenanceHistoryModel {}

  export class Event extends EventModel {}

  export class VehicleEvent extends VehicleEventModel {}

  export class ServiceRecommendation extends ServiceRecommendationModel {}
}
