import { MaintenanceTask } from '../maintenanceTask'

import { ServiceMilestone } from '../serviceMilestone'

import { FuelRecord } from '../fuelRecord'

import { MaintenanceHistory } from '../maintenanceHistory'

import { VehicleEvent } from '../vehicleEvent'

import { ServiceRecommendation } from '../serviceRecommendation'

export class Vehicle {
  id: string

  licensePlate: string

  model: string

  make: string

  year: number

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  maintenanceTasks?: MaintenanceTask[]

  serviceMilestones?: ServiceMilestone[]

  fuelRecords?: FuelRecord[]

  maintenanceHistorys?: MaintenanceHistory[]

  vehicleEvents?: VehicleEvent[]

  serviceRecommendations?: ServiceRecommendation[]
}
