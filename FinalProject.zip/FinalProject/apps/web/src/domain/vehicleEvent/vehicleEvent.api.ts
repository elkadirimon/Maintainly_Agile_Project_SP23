import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { VehicleEvent } from './vehicleEvent.model'

export class VehicleEventApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<VehicleEvent>,
  ): Promise<VehicleEvent[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/vehicleEvents${buildOptions}`)
  }

  static findOne(
    vehicleEventId: string,
    queryOptions?: ApiHelper.QueryOptions<VehicleEvent>,
  ): Promise<VehicleEvent> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/vehicleEvents/${vehicleEventId}${buildOptions}`,
    )
  }

  static createOne(values: Partial<VehicleEvent>): Promise<VehicleEvent> {
    return HttpService.api.post(`/v1/vehicleEvents`, values)
  }

  static updateOne(
    vehicleEventId: string,
    values: Partial<VehicleEvent>,
  ): Promise<VehicleEvent> {
    return HttpService.api.patch(`/v1/vehicleEvents/${vehicleEventId}`, values)
  }

  static deleteOne(vehicleEventId: string): Promise<void> {
    return HttpService.api.delete(`/v1/vehicleEvents/${vehicleEventId}`)
  }

  static findManyByVehicleId(
    vehicleId: string,
    queryOptions?: ApiHelper.QueryOptions<VehicleEvent>,
  ): Promise<VehicleEvent[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/vehicles/vehicle/${vehicleId}/vehicleEvents${buildOptions}`,
    )
  }

  static createOneByVehicleId(
    vehicleId: string,
    values: Partial<VehicleEvent>,
  ): Promise<VehicleEvent> {
    return HttpService.api.post(
      `/v1/vehicles/vehicle/${vehicleId}/vehicleEvents`,
      values,
    )
  }

  static findManyByEventId(
    eventId: string,
    queryOptions?: ApiHelper.QueryOptions<VehicleEvent>,
  ): Promise<VehicleEvent[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/events/event/${eventId}/vehicleEvents${buildOptions}`,
    )
  }

  static createOneByEventId(
    eventId: string,
    values: Partial<VehicleEvent>,
  ): Promise<VehicleEvent> {
    return HttpService.api.post(
      `/v1/events/event/${eventId}/vehicleEvents`,
      values,
    )
  }
}
