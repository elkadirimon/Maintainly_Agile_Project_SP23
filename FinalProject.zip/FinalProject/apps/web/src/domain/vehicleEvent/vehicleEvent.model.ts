import { Vehicle } from '../vehicle'

import { Event } from '../event'

export class VehicleEvent {
  id: string

  vehicleId: string

  vehicle?: Vehicle

  eventId: string

  event?: Event

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
