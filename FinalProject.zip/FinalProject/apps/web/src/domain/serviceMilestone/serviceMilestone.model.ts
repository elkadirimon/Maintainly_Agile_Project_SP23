import { Vehicle } from '../vehicle'

export class ServiceMilestone {
  id: string

  milestoneType: string

  dueDate: string

  vehicleId: string

  vehicle?: Vehicle

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
