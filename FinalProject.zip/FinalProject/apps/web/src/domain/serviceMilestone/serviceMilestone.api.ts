import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { ServiceMilestone } from './serviceMilestone.model'

export class ServiceMilestoneApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<ServiceMilestone>,
  ): Promise<ServiceMilestone[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/serviceMilestones${buildOptions}`)
  }

  static findOne(
    serviceMilestoneId: string,
    queryOptions?: ApiHelper.QueryOptions<ServiceMilestone>,
  ): Promise<ServiceMilestone> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/serviceMilestones/${serviceMilestoneId}${buildOptions}`,
    )
  }

  static createOne(
    values: Partial<ServiceMilestone>,
  ): Promise<ServiceMilestone> {
    return HttpService.api.post(`/v1/serviceMilestones`, values)
  }

  static updateOne(
    serviceMilestoneId: string,
    values: Partial<ServiceMilestone>,
  ): Promise<ServiceMilestone> {
    return HttpService.api.patch(
      `/v1/serviceMilestones/${serviceMilestoneId}`,
      values,
    )
  }

  static deleteOne(serviceMilestoneId: string): Promise<void> {
    return HttpService.api.delete(`/v1/serviceMilestones/${serviceMilestoneId}`)
  }

  static findManyByVehicleId(
    vehicleId: string,
    queryOptions?: ApiHelper.QueryOptions<ServiceMilestone>,
  ): Promise<ServiceMilestone[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/vehicles/vehicle/${vehicleId}/serviceMilestones${buildOptions}`,
    )
  }

  static createOneByVehicleId(
    vehicleId: string,
    values: Partial<ServiceMilestone>,
  ): Promise<ServiceMilestone> {
    return HttpService.api.post(
      `/v1/vehicles/vehicle/${vehicleId}/serviceMilestones`,
      values,
    )
  }
}
