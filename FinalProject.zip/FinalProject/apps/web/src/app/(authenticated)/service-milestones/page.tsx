'use client'

import { useState, useEffect } from 'react'
import { Typography, Table, Tag, Space } from 'antd'
import { ClockCircleOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ServiceMilestonesPage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id

  const [serviceMilestones, setServiceMilestones] = useState([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const milestones = await Api.ServiceMilestone.findMany({
          includes: ['vehicle'],
        })
        setServiceMilestones(milestones)
      } catch (error) {
        enqueueSnackbar('Failed to fetch service milestones', {
          variant: 'error',
        })
      }
    }

    fetchData()
  }, [])

  const columns = [
    {
      title: 'Vehicle',
      dataIndex: ['vehicle', 'licensePlate'],
      key: 'vehicle',
    },
    {
      title: 'Milestone Type',
      dataIndex: 'milestoneType',
      key: 'milestoneType',
    },
    {
      title: 'Due Date',
      dataIndex: 'dueDate',
      key: 'dueDate',
      render: dueDate => dayjs(dueDate).format('YYYY-MM-DD'),
    },
    {
      title: 'Status',
      key: 'status',
      render: (_, record) => (
        <Tag
          color={dayjs().isAfter(dayjs(record.dueDate)) ? 'volcano' : 'green'}
        >
          {dayjs().isAfter(dayjs(record.dueDate)) ? 'Overdue' : 'Upcoming'}
        </Tag>
      ),
    },
    {
      title: 'Action',
      key: 'action',
      render: (_, record) => (
        <Space size="middle">
          <a onClick={() => router.push(`/vehicle/${record.vehicleId}`)}>
            View Details
          </a>
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="narrow">
      <Title level={2}>
        <ClockCircleOutlined /> Service Milestones
      </Title>
      <Text type="secondary">
        Here you can view upcoming and past service milestones for vehicles in
        the fleet.
      </Text>
      <Table columns={columns} dataSource={serviceMilestones} rowKey="id" />
    </PageLayout>
  )
}
