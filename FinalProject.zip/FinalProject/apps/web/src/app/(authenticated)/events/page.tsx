'use client'

import { useEffect, useState } from 'react'
import { Typography, Table, Tag, Space, Button } from 'antd'
import { ClockCircleOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function EventMonitoringPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const { enqueueSnackbar } = useSnackbar()
  const [events, setEvents] = useState([])

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const eventsFound = await Api.Event.findMany({
          includes: ['vehicleEvents', 'vehicleEvents.vehicle'],
        })
        setEvents(eventsFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch events', { variant: 'error' })
      }
    }

    fetchEvents()
  }, [])

  const columns = [
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description',
    },
    {
      title: 'Start Time',
      dataIndex: 'startTime',
      key: 'startTime',
      render: text => dayjs(text).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: 'End Time',
      dataIndex: 'endTime',
      key: 'endTime',
      render: text => dayjs(text).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: 'Vehicles Involved',
      key: 'vehicleEvents',
      dataIndex: 'vehicleEvents',
      render: (_, { vehicleEvents }) => (
        <>
          {vehicleEvents?.map(ve => (
            <Tag color="blue" key={ve.vehicle.id}>
              {ve.vehicle.licensePlate}
            </Tag>
          ))}
        </>
      ),
    },
    {
      title: 'Action',
      key: 'action',
      render: (_, record) => (
        <Space size="middle">
          <Button
            onClick={() =>
              router.push(`/vehicle/${record.vehicleEvents[0]?.vehicle.id}`)
            }
          >
            View Details
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="narrow">
      <Title level={2}>
        <ClockCircleOutlined /> Event Monitoring
      </Title>
      <Text>
        Monitor real-time events related to the fleet, providing insights into
        ongoing activities and statuses.
      </Text>
      <Table columns={columns} dataSource={events} rowKey="id" />
    </PageLayout>
  )
}
