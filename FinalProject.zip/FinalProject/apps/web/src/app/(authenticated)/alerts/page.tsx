'use client'

import { useEffect, useState } from 'react'
import { Button, Card, Col, Row, Typography, Spin, List, Avatar } from 'antd'
import { BellOutlined, CarOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function RealTimeAlertsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [loading, setLoading] = useState(true)
  const [notifications, setNotifications] = useState([])

  useEffect(() => {
    if (!userId) {
      enqueueSnackbar('User not authenticated', { variant: 'error' })
      router.push('/home')
      return
    }

    const fetchNotifications = async () => {
      try {
        const notificationsFound = await Api.Notification.findMany({
          filters: { userId: { eq: userId } },
          includes: ['user'],
        })
        setNotifications(notificationsFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch notifications', { variant: 'error' })
      } finally {
        setLoading(false)
      }
    }

    fetchNotifications()
  }, [userId, router])

  return (
    <PageLayout layout="narrow">
      <Title level={2}>
        <BellOutlined /> Real-Time Alerts
      </Title>
      <Paragraph>
        This page provides a centralized hub for viewing and managing all
        real-time alerts and notifications related to the fleet's status and
        maintenance needs.
      </Paragraph>
      {loading ? (
        <Spin size="large" />
      ) : (
        <List
          itemLayout="horizontal"
          dataSource={notifications}
          renderItem={item => (
            <List.Item
              actions={[
                <Button
                  type="link"
                  onClick={() => router.push(item.redirectUrl)}
                >
                  View
                </Button>,
              ]}
            >
              <List.Item.Meta
                avatar={<Avatar icon={<CarOutlined />} />}
                title={<Text strong>{item.title}</Text>}
                description={item.message}
              />
              <div>{dayjs(item.dateCreated).format('DD MMM YYYY')}</div>
            </List.Item>
          )}
        />
      )}
    </PageLayout>
  )
}
