'use client'

import { useEffect, useState } from 'react'
import { Typography, Table, Button, Space } from 'antd'
import { CarOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function FuelRecordsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [vehicles, setVehicles] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const fetchVehicles = async () => {
      setLoading(true)
      try {
        const vehiclesFound = await Api.Vehicle.findMany({
          includes: ['fuelRecords'],
        })
        setVehicles(vehiclesFound)
        setLoading(false)
      } catch (error) {
        enqueueSnackbar('Failed to fetch vehicles', { variant: 'error' })
        setLoading(false)
      }
    }

    fetchVehicles()
  }, [])

  const columns = [
    {
      title: 'License Plate',
      dataIndex: 'licensePlate',
      key: 'licensePlate',
    },
    {
      title: 'Model',
      dataIndex: 'model',
      key: 'model',
    },
    {
      title: 'Make',
      dataIndex: 'make',
      key: 'make',
    },
    {
      title: 'Year',
      dataIndex: 'year',
      key: 'year',
    },
    {
      title: 'Fuel Records',
      dataIndex: 'fuelRecords',
      key: 'fuelRecords',
      render: fuelRecords => (
        <Space direction="vertical">
          {fuelRecords?.map(record => (
            <Text key={record.id}>
              {dayjs(record.date).format('DD/MM/YYYY')} - {record.fuelVolume}{' '}
              liters
            </Text>
          ))}
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="narrow">
      <Title level={2}>
        <CarOutlined /> Fuel Consumption Records
      </Title>
      <Text type="secondary">
        Below is the list of vehicles and their respective fuel consumption
        records.
      </Text>
      <Table
        columns={columns}
        dataSource={vehicles}
        rowKey="id"
        loading={loading}
        pagination={{ pageSize: 5 }}
      />
    </PageLayout>
  )
}
