'use client'

import { useEffect, useState } from 'react'
import { Typography, Table, Button, Space } from 'antd'
import { CarOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
interface MaintenanceData {
  key: string
  vehicleModel: string
  vehicleMake: string
  dueDate: string
  status: string
}
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function PredictiveMaintenanceReportsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [maintenanceTasks, setMaintenanceTasks] = useState<MaintenanceData[]>(
    [],
  )

  useEffect(() => {
    const fetchMaintenanceTasks = async () => {
      try {
        const tasks = await Api.MaintenanceTask.findMany({
          includes: ['vehicle', 'maintenanceHistorysAsTask.vehicle'],
        })
        const formattedTasks = tasks.map(task => ({
          key: task.id,
          vehicleModel: task.vehicle?.model ?? 'Unknown',
          vehicleMake: task.vehicle?.make ?? 'Unknown',
          dueDate: dayjs(task.dueDate).format('YYYY-MM-DD'),
          status: task.status,
        }))
        setMaintenanceTasks(formattedTasks)
      } catch (error) {
        enqueueSnackbar('Failed to fetch maintenance tasks.', {
          variant: 'error',
        })
      }
    }

    fetchMaintenanceTasks()
  }, [])

  const columns = [
    {
      title: 'Vehicle Model',
      dataIndex: 'vehicleModel',
      key: 'vehicleModel',
    },
    {
      title: 'Vehicle Make',
      dataIndex: 'vehicleMake',
      key: 'vehicleMake',
    },
    {
      title: 'Due Date',
      dataIndex: 'dueDate',
      key: 'dueDate',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
    },
    {
      title: 'Action',
      key: 'action',
      render: (_, record) => (
        <Space size="middle">
          <Button onClick={() => router.push(`/vehicle/${record.key}`)}>
            View Details
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="narrow">
      <Title level={2}>
        <CarOutlined /> Predictive Maintenance Reports
      </Title>
      <Text>
        Access detailed reports on predictive maintenance for the fleet, helping
        to prevent vehicle downtime and optimize maintenance schedules.
      </Text>
      <Table columns={columns} dataSource={maintenanceTasks} />
    </PageLayout>
  )
}
