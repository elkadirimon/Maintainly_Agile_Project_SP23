'use client'

import { useEffect, useState } from 'react'
import { Button, Table, Tag, Typography } from 'antd'
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  CarOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function OngoingMaintenancePage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id

  const [vehicles, setVehicles] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchVehicles()
  }, [])

  const fetchVehicles = async () => {
    setLoading(true)
    try {
      const vehiclesFound = await Api.Vehicle.findMany({
        includes: ['maintenanceTasks'],
      })
      setVehicles(vehiclesFound)
    } catch (error) {
      enqueueSnackbar('Failed to fetch vehicles', { variant: 'error' })
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteTask = async taskId => {
    try {
      await Api.MaintenanceTask.deleteOne(taskId)
      enqueueSnackbar('Maintenance task deleted successfully', {
        variant: 'success',
      })
      fetchVehicles() // Refresh list after deletion
    } catch (error) {
      enqueueSnackbar('Failed to delete maintenance task', { variant: 'error' })
    }
  }

  const columns = [
    {
      title: 'License Plate',
      dataIndex: 'licensePlate',
      key: 'licensePlate',
      render: text => <Text strong>{text}</Text>,
    },
    {
      title: 'Model',
      dataIndex: 'model',
      key: 'model',
    },
    {
      title: 'Maintenance Tasks',
      key: 'maintenanceTasks',
      render: (_, record) =>
        record.maintenanceTasks?.map(task => (
          <Tag
            color={task.status === 'pending' ? 'volcano' : 'green'}
            key={task.id}
          >
            {task.description} - Due {dayjs(task.dueDate).format('DD/MM/YYYY')}
          </Tag>
        )),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <>
          <Button
            icon={<EditOutlined />}
            onClick={() =>
              router.push(`/schedule-maintenance?vehicleId=${record.id}`)
            }
          >
            Edit
          </Button>
          <Button
            icon={<DeleteOutlined />}
            onClick={() => handleDeleteTask(record.id)}
            style={{ marginLeft: 8 }}
          >
            Delete
          </Button>
        </>
      ),
    },
  ]

  return (
    <PageLayout layout="narrow">
      <Title level={2}>
        <CarOutlined /> Ongoing Maintenance
      </Title>
      <Text type="secondary">
        Manage and monitor maintenance tasks for each vehicle in the fleet.
      </Text>
      <Button
        type="primary"
        icon={<PlusOutlined />}
        onClick={() => router.push('/schedule-maintenance')}
        style={{ marginBottom: 16 }}
      >
        Add Maintenance Task
      </Button>
      <Table
        columns={columns}
        dataSource={vehicles}
        rowKey="id"
        loading={loading}
      />
    </PageLayout>
  )
}
