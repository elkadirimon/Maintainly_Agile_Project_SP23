'use client'

import { useEffect, useState } from 'react'
import { Button, Form, Input, DatePicker, Select, Typography } from 'antd'
import { PlusOutlined, DeleteOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
const { Option } = Select
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ScheduleMaintenancePage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const [vehicles, setVehicles] = useState([])
  const [form] = Form.useForm()

  useEffect(() => {
    const fetchVehicles = async () => {
      try {
        const vehiclesFound = await Api.Vehicle.findMany({
          includes: ['maintenanceTasks'],
        })
        setVehicles(vehiclesFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch vehicles', { variant: 'error' })
      }
    }

    fetchVehicles()
  }, [])

  const handleSubmit = async values => {
    try {
      const { vehicleId, description, dueDate } = values
      await Api.MaintenanceTask.createOneByVehicleId(vehicleId, {
        description,
        dueDate: dayjs(dueDate).format('YYYY-MM-DD'),
        status: 'Scheduled',
      })
      enqueueSnackbar('Maintenance task scheduled successfully', {
        variant: 'success',
      })
      form.resetFields()
    } catch (error) {
      enqueueSnackbar('Failed to schedule maintenance task', {
        variant: 'error',
      })
    }
  }

  const handleVehicleChange = vehicleId => {
    router.push(`/vehicle/${vehicleId}`)
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Schedule Vehicle Maintenance</Title>
      <Text>
        Please fill out the form to schedule a maintenance task for a vehicle.
      </Text>
      <Form form={form} layout="vertical" onFinish={handleSubmit}>
        <Form.Item
          name="vehicleId"
          label="Select Vehicle"
          rules={[{ required: true, message: 'Please select a vehicle' }]}
        >
          <Select placeholder="Select a vehicle" onChange={handleVehicleChange}>
            {vehicles?.map(vehicle => (
              <Option key={vehicle.id} value={vehicle.id}>
                {vehicle.licensePlate} - {vehicle.model}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          name="description"
          label="Task Description"
          rules={[{ required: true, message: 'Please enter a description' }]}
        >
          <Input placeholder="Describe the maintenance task" />
        </Form.Item>
        <Form.Item
          name="dueDate"
          label="Due Date"
          rules={[{ required: true, message: 'Please select a due date' }]}
        >
          <DatePicker style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit" icon={<PlusOutlined />}>
            Schedule Task
          </Button>
        </Form.Item>
      </Form>
    </PageLayout>
  )
}
