'use client'

import { useEffect, useState } from 'react'
import { Button, Card, Col, Row, Typography, Spin, Space } from 'antd'
import {
  CarOutlined,
  ToolOutlined,
  CalendarOutlined,
  AlertOutlined,
  FireOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function HomePage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id

  const [vehicles, setVehicles] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchVehicles() {
      try {
        const vehiclesFound = await Api.Vehicle.findMany({
          includes: ['maintenanceTasks', 'serviceMilestones', 'fuelRecords'],
        })
        setVehicles(vehiclesFound)
        setLoading(false)
      } catch (error) {
        enqueueSnackbar('Failed to fetch vehicles', { variant: 'error' })
        setLoading(false)
      }
    }

    fetchVehicles()
  }, [])

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Fleet Overview Dashboard</Title>
      <Text type="secondary">
        Comprehensive overview of the fleet's status and quick access to various
        functionalities.
      </Text>
      <Space direction="vertical" size="large" style={{ width: '100%' }}>
        {loading ? (
          <Spin size="large" />
        ) : (
          <Row gutter={[16, 16]}>
            {vehicles?.map(vehicle => (
              <Col key={vehicle.id} xs={24} sm={12} md={8} lg={6}>
                <Card
                  title={vehicle.model}
                  actions={[
                    <Button
                      type="link"
                      icon={<CarOutlined />}
                      onClick={() => router.push(`/vehicle/${vehicle.id}`)}
                    >
                      Details
                    </Button>,
                    <Button
                      type="link"
                      icon={<ToolOutlined />}
                      onClick={() => router.push('/maintenance-tasks')}
                    >
                      Maintenance
                    </Button>,
                    <Button
                      type="link"
                      icon={<CalendarOutlined />}
                      onClick={() => router.push('/service-milestones')}
                    >
                      Milestones
                    </Button>,
                    <Button
                      type="link"
                      icon={<AlertOutlined />}
                      onClick={() => router.push('/alerts')}
                    >
                      Alerts
                    </Button>,
                    <Button
                      type="link"
                      icon={<FireOutlined />}
                      onClick={() => router.push('/fuel-records')}
                    >
                      Fuel Records
                    </Button>,
                  ]}
                >
                  <p>
                    <strong>License Plate:</strong> {vehicle.licensePlate}
                  </p>
                  <p>
                    <strong>Make:</strong> {vehicle.make}
                  </p>
                  <p>
                    <strong>Year:</strong> {vehicle.year}
                  </p>
                  <p>
                    <strong>Last Service:</strong>{' '}
                    {vehicle.serviceMilestones?.[0]
                      ? dayjs(vehicle.serviceMilestones[0].dueDate).format(
                          'DD/MM/YYYY',
                        )
                      : 'N/A'}
                  </p>
                </Card>
              </Col>
            ))}
          </Row>
        )}
      </Space>
    </PageLayout>
  )
}
