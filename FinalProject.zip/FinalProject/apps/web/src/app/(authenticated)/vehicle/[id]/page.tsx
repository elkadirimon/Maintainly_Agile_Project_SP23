'use client'

import React, { useEffect, useState } from 'react'
import { Typography, Descriptions, Card, Col, Row, Spin, Alert } from 'antd'
import { CarOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function VehicleDetailsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { vehicleId } = params
  const authentication = useAuthentication()
  const { enqueueSnackbar } = useSnackbar()
  const [vehicle, setVehicle] = useState<Model.Vehicle | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!authentication.isAuthenticated) {
      router.push('/home')
      return
    }

    const fetchVehicle = async () => {
      try {
        const vehicleData = await Api.Vehicle.findOne(vehicleId, {
          includes: [
            'maintenanceTasks',
            'serviceMilestones',
            'fuelRecords',
            'maintenanceHistorys',
            'vehicleEvents',
            'serviceRecommendations',
          ],
        })
        setVehicle(vehicleData)
      } catch (err) {
        enqueueSnackbar('Failed to fetch vehicle details', { variant: 'error' })
        setError('Failed to load vehicle data. Please try again later.')
      } finally {
        setLoading(false)
      }
    }

    fetchVehicle()
  }, [vehicleId, authentication.isAuthenticated])

  if (loading) {
    return (
      <PageLayout layout="narrow">
        <Spin size="large" />
      </PageLayout>
    )
  }

  if (error) {
    return (
      <PageLayout layout="narrow">
        <Alert type="error" message={error} />
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>
        <CarOutlined /> Vehicle Details
      </Title>
      <Descriptions bordered column={1}>
        <Descriptions.Item label="License Plate">
          {vehicle?.licensePlate}
        </Descriptions.Item>
        <Descriptions.Item label="Model">{vehicle?.model}</Descriptions.Item>
        <Descriptions.Item label="Make">{vehicle?.make}</Descriptions.Item>
        <Descriptions.Item label="Year">{vehicle?.year}</Descriptions.Item>
        <Descriptions.Item label="Date Created">
          {dayjs(vehicle?.dateCreated).format('YYYY-MM-DD')}
        </Descriptions.Item>
      </Descriptions>

      <Title level={4} style={{ marginTop: '20px' }}>
        Maintenance Tasks
      </Title>
      <Row gutter={[16, 16]}>
        {vehicle?.maintenanceTasks?.map((task, index) => (
          <Col span={8} key={index}>
            <Card title={task.description} bordered>
              <Text>Status: {task.status}</Text>
              <br />
              <Text>Due Date: {dayjs(task.dueDate).format('YYYY-MM-DD')}</Text>
            </Card>
          </Col>
        ))}
      </Row>
    </PageLayout>
  )
}
