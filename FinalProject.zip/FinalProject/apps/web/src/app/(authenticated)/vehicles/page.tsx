'use client'

import { useEffect, useState } from 'react'
import { Typography, Table, Button, Space, Tag } from 'antd'
import { CarOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function FleetOverviewPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [vehicles, setVehicles] = useState<Model.Vehicle[]>([])

  useEffect(() => {
    const fetchVehicles = async () => {
      try {
        const vehiclesFound = await Api.Vehicle.findMany({
          includes: ['maintenanceTasks', 'serviceMilestones', 'fuelRecords'],
        })
        setVehicles(vehiclesFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch vehicles', { variant: 'error' })
      }
    }

    fetchVehicles()
  }, [])

  const columns = [
    {
      title: 'License Plate',
      dataIndex: 'licensePlate',
      key: 'licensePlate',
    },
    {
      title: 'Model',
      dataIndex: 'model',
      key: 'model',
    },
    {
      title: 'Make',
      dataIndex: 'make',
      key: 'make',
    },
    {
      title: 'Year',
      dataIndex: 'year',
      key: 'year',
    },
    {
      title: 'Maintenance Tasks',
      key: 'maintenanceTasks',
      render: (_, record) => (
        <Space size="middle">
          {record.maintenanceTasks?.map(task => (
            <Tag color="volcano" key={task.id}>
              {task.description}
            </Tag>
          ))}
        </Space>
      ),
    },
    {
      title: 'Service Milestones',
      key: 'serviceMilestones',
      render: (_, record) => (
        <Space size="middle">
          {record.serviceMilestones?.map(milestone => (
            <Tag color="geekblue" key={milestone.id}>
              {milestone.milestoneType}
            </Tag>
          ))}
        </Space>
      ),
    },
    {
      title: 'Details',
      key: 'details',
      render: (_, record) => (
        <Button
          onClick={() => router.push(`/vehicle/${record.id}`)}
          type="primary"
        >
          View Details
        </Button>
      ),
    },
  ]

  return (
    <PageLayout layout="narrow">
      <Title level={2}>
        <CarOutlined /> Fleet Overview
      </Title>
      <Text type="secondary">
        Comprehensive view of all vehicles in the fleet.
      </Text>
      <Table columns={columns} dataSource={vehicles} rowKey="id" />
    </PageLayout>
  )
}
