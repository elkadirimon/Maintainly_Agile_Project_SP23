import { MigrationInterface, QueryRunner } from 'typeorm'

export class Script1702311247028 implements MigrationInterface {
  name = 'Script1702311247028'

  public async up(queryRunner: QueryRunner): Promise<void> {
    try {
      await queryRunner.query(
        `
        INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('667c0dc9-0d7b-4ed5-aa1b-96b328a6ffd5', '1Garry29@gmail.com', 'Eve Davis', 'https://i.imgur.com/YfJQV5z.png?id=3', 'pending', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('f2320f2d-d79d-46cb-a694-34ade9845276', '7Henriette_Cole@hotmail.com', 'Alice Johnson', 'https://i.imgur.com/YfJQV5z.png?id=9', 'pending', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('bc6692e6-71f6-45cb-9726-1fec9b2ff5b9', '19Margarita23@yahoo.com', 'Eve Davis', 'https://i.imgur.com/YfJQV5z.png?id=21', 'deleted', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('ec363af3-9cfc-4dab-9ec5-c6d71bbb6e16', '25Patsy.Powlowski@hotmail.com', 'Dave Brown', 'https://i.imgur.com/YfJQV5z.png?id=27', 'suspended', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('f232568a-6222-42e8-93ab-2fea419f2179', '31Kim_Tromp@hotmail.com', 'Carol White', 'https://i.imgur.com/YfJQV5z.png?id=33', 'active', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('9935f034-c889-4128-bebd-90e556077146', '37Shana.Trantow39@hotmail.com', 'Eve Davis', 'https://i.imgur.com/YfJQV5z.png?id=39', 'pending', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('1cf32d15-dd8b-467a-9ef5-8d952302637a', '43Armand.Ernser@yahoo.com', 'Eve Davis', 'https://i.imgur.com/YfJQV5z.png?id=45', 'deleted', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('eb97c809-2f89-4dfe-895f-0c482ec25b5b', '49Madisyn_Ruecker@hotmail.com', 'Bob Smith', 'https://i.imgur.com/YfJQV5z.png?id=51', 'active', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('fbbb19cc-66cb-42df-9297-61a004f76383', '55Mireya_Jerde@gmail.com', 'Carol White', 'https://i.imgur.com/YfJQV5z.png?id=57', 'deleted', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');

INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('44b3ece5-2454-4df7-afb3-d76e321ec06f', 'Fuel Status Update', 'Vehicle ID 1234 requires immediate attention for brake servicing.', 'Jane Smith', '64Shanny34@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=65', 'https://i.imgur.com/YfJQV5z.png?id=66', 'fbbb19cc-66cb-42df-9297-61a004f76383');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('e0913788-8595-4e03-be57-9c5b277ccc6b', 'Urgent Repair Needed', 'Monthly health report for Vehicle ID 7890 is available.', 'Mike Johnson', '71Amalia_Walker@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=72', 'https://i.imgur.com/YfJQV5z.png?id=73', '667c0dc9-0d7b-4ed5-aa1b-96b328a6ffd5');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('e8b6fbd5-84b0-4f20-8e46-c5d330898c06', 'Fuel Status Update', 'Critical engine repair needed for Vehicle ID 9012.', 'Jane Smith', '78Keon_Glover@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=79', 'https://i.imgur.com/YfJQV5z.png?id=80', 'ec363af3-9cfc-4dab-9ec5-c6d71bbb6e16');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('61b1cc69-8b04-4748-9452-398500934185', 'Urgent Repair Needed', 'Critical engine repair needed for Vehicle ID 9012.', 'Mike Johnson', '85Carlos.Stark79@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=86', 'https://i.imgur.com/YfJQV5z.png?id=87', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('e986484f-f957-4f53-aed8-f943123cf0f5', 'Service Reminder', 'Fuel level low in Vehicle ID 3456 please refuel.', 'Jane Smith', '92Hillary.Padberg@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=93', 'https://i.imgur.com/YfJQV5z.png?id=94', 'bc6692e6-71f6-45cb-9726-1fec9b2ff5b9');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('b9535e87-7386-40cf-a115-5ecc0a24e1ab', 'Maintenance Alert', 'Fuel level low in Vehicle ID 3456 please refuel.', 'Mike Johnson', '99Blair_Cremin@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=100', 'https://i.imgur.com/YfJQV5z.png?id=101', 'bc6692e6-71f6-45cb-9726-1fec9b2ff5b9');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('2cceb421-a439-4043-9bef-fae8b3f17f7a', 'Fuel Status Update', 'Monthly health report for Vehicle ID 7890 is available.', 'Alex Brown', '106Rafael.Lesch@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=107', 'https://i.imgur.com/YfJQV5z.png?id=108', '1cf32d15-dd8b-467a-9ef5-8d952302637a');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('82b37d91-c85d-4eb7-bc30-e5aa016617ac', 'Fuel Status Update', 'Critical engine repair needed for Vehicle ID 9012.', 'Jane Smith', '113Gertrude8@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=114', 'https://i.imgur.com/YfJQV5z.png?id=115', 'eb97c809-2f89-4dfe-895f-0c482ec25b5b');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('f82b36bf-80bc-45d0-92d8-bbf6b2ca97bb', 'Vehicle Health Report', 'Vehicle ID 1234 requires immediate attention for brake servicing.', 'Alex Brown', '120Casimir_Muller@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=121', 'https://i.imgur.com/YfJQV5z.png?id=122', 'f232568a-6222-42e8-93ab-2fea419f2179');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('bfc07158-7013-441c-85c4-bf2544be4d78', 'Fuel Status Update', 'Critical engine repair needed for Vehicle ID 9012.', 'Alex Brown', '127Lilyan_Champlin@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=128', 'https://i.imgur.com/YfJQV5z.png?id=129', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');

INSERT INTO "vehicle" ("id", "licensePlate", "model", "make", "year") VALUES ('07534871-f49e-4b7a-b2b1-855141d4839b', 'HJK9012', 'Accord', 'Honda', 641);
INSERT INTO "vehicle" ("id", "licensePlate", "model", "make", "year") VALUES ('cc29d02e-b596-4f02-8639-e558c2260eea', 'QRS7890', 'Model S', 'Toyota', 646);
INSERT INTO "vehicle" ("id", "licensePlate", "model", "make", "year") VALUES ('3c2f8ff3-9797-4b64-b23a-7fda395827ed', 'XYZ1234', 'Corolla', 'Ford', 161);
INSERT INTO "vehicle" ("id", "licensePlate", "model", "make", "year") VALUES ('2d7fa795-b655-462e-b957-42cc8f2f41bf', 'ABC5678', 'Civic', 'Honda', 238);
INSERT INTO "vehicle" ("id", "licensePlate", "model", "make", "year") VALUES ('659530b7-0c0f-44a5-ac7a-27b08c39e57f', 'HJK9012', 'Accord', 'Honda', 199);
INSERT INTO "vehicle" ("id", "licensePlate", "model", "make", "year") VALUES ('7195f575-8c5d-4eff-b1be-01c1656e93f7', 'ABC5678', 'Corolla', 'Ford', 139);
INSERT INTO "vehicle" ("id", "licensePlate", "model", "make", "year") VALUES ('39cfe9d9-ae3f-4aa5-ad9e-7a3a49e7734f', 'XYZ1234', 'Civic', 'Toyota', 790);
INSERT INTO "vehicle" ("id", "licensePlate", "model", "make", "year") VALUES ('de7a2f61-2835-46d4-b44a-b3911f3a44cf', 'LMN3456', 'Model S', 'Tesla', 897);
INSERT INTO "vehicle" ("id", "licensePlate", "model", "make", "year") VALUES ('8596c707-d585-439a-aad1-f0a8b4bf71ef', 'ABC5678', 'Civic', 'Honda', 9);
INSERT INTO "vehicle" ("id", "licensePlate", "model", "make", "year") VALUES ('d8947cc5-8c50-4856-ad1f-2ff652afc692', 'HJK9012', 'Accord', 'Toyota', 61);

INSERT INTO "maintenance_task" ("id", "description", "dueDate", "status", "vehicleId") VALUES ('eb289666-4079-4d65-9a69-a15494d3d157', 'Brake system overhaul', '2023-10-09T21:32:01.238Z', 'Scheduled', 'cc29d02e-b596-4f02-8639-e558c2260eea');
INSERT INTO "maintenance_task" ("id", "description", "dueDate", "status", "vehicleId") VALUES ('84adbe5f-4244-4275-93f1-69b08beff5c6', 'Engine diagnostics and tuneup', '2024-06-18T17:35:23.887Z', 'Completed', 'de7a2f61-2835-46d4-b44a-b3911f3a44cf');
INSERT INTO "maintenance_task" ("id", "description", "dueDate", "status", "vehicleId") VALUES ('744f5265-c29d-4041-a931-731294e7a66e', 'Battery inspection and replacement', '2023-05-26T10:48:18.716Z', 'Pending', '8596c707-d585-439a-aad1-f0a8b4bf71ef');
INSERT INTO "maintenance_task" ("id", "description", "dueDate", "status", "vehicleId") VALUES ('f0a29740-60fd-40bc-b4db-88194c98a331', 'Engine diagnostics and tuneup', '2025-04-11T11:53:45.660Z', 'In Progress', '7195f575-8c5d-4eff-b1be-01c1656e93f7');
INSERT INTO "maintenance_task" ("id", "description", "dueDate", "status", "vehicleId") VALUES ('23af9a4b-6bc5-418e-96d9-019f54920e63', 'Oil change and filter replacement', '2024-04-27T12:26:40.108Z', 'Scheduled', 'de7a2f61-2835-46d4-b44a-b3911f3a44cf');
INSERT INTO "maintenance_task" ("id", "description", "dueDate", "status", "vehicleId") VALUES ('031fcf17-c93d-48dd-831f-e2ccbb091b0e', 'Tire rotation and alignment check', '2023-05-22T18:44:53.803Z', 'Pending', '39cfe9d9-ae3f-4aa5-ad9e-7a3a49e7734f');
INSERT INTO "maintenance_task" ("id", "description", "dueDate", "status", "vehicleId") VALUES ('cb1e104f-24ca-42f7-86fc-dbd4e0e35a96', 'Oil change and filter replacement', '2023-12-09T18:15:19.512Z', 'Scheduled', 'cc29d02e-b596-4f02-8639-e558c2260eea');
INSERT INTO "maintenance_task" ("id", "description", "dueDate", "status", "vehicleId") VALUES ('ad7d43dc-ea67-4666-a6ae-188afb885925', 'Engine diagnostics and tuneup', '2023-12-16T21:00:52.217Z', 'In Progress', '3c2f8ff3-9797-4b64-b23a-7fda395827ed');
INSERT INTO "maintenance_task" ("id", "description", "dueDate", "status", "vehicleId") VALUES ('f1978291-057b-420c-937c-9d7d6050553b', 'Brake system overhaul', '2024-04-16T14:19:33.994Z', 'Scheduled', '07534871-f49e-4b7a-b2b1-855141d4839b');
INSERT INTO "maintenance_task" ("id", "description", "dueDate", "status", "vehicleId") VALUES ('006095c8-9a34-4e8d-b7d6-f1b330930e1e', 'Engine diagnostics and tuneup', '2024-04-17T08:21:43.962Z', 'Cancelled', '7195f575-8c5d-4eff-b1be-01c1656e93f7');

INSERT INTO "service_milestone" ("id", "milestoneType", "dueDate", "vehicleId") VALUES ('f1f5fb93-4387-47aa-897b-f7f9c9ed3f2e', 'Brake Inspection', '2025-03-23T04:41:32.901Z', '7195f575-8c5d-4eff-b1be-01c1656e93f7');
INSERT INTO "service_milestone" ("id", "milestoneType", "dueDate", "vehicleId") VALUES ('ce81e473-e385-47fa-ae00-449edf477ce3', 'Transmission Check', '2023-12-08T03:20:10.935Z', '7195f575-8c5d-4eff-b1be-01c1656e93f7');
INSERT INTO "service_milestone" ("id", "milestoneType", "dueDate", "vehicleId") VALUES ('9e83a0ec-c24f-4d34-a936-c60d1524341a', 'Brake Inspection', '2024-07-19T03:49:40.607Z', 'de7a2f61-2835-46d4-b44a-b3911f3a44cf');
INSERT INTO "service_milestone" ("id", "milestoneType", "dueDate", "vehicleId") VALUES ('16e45900-ce90-4d76-a3a5-a6de5a34c5cd', 'Transmission Check', '2024-04-23T06:17:21.290Z', '2d7fa795-b655-462e-b957-42cc8f2f41bf');
INSERT INTO "service_milestone" ("id", "milestoneType", "dueDate", "vehicleId") VALUES ('e711fd33-cbda-4d65-91dc-990116665c76', 'Transmission Check', '2024-09-05T12:47:39.289Z', 'de7a2f61-2835-46d4-b44a-b3911f3a44cf');
INSERT INTO "service_milestone" ("id", "milestoneType", "dueDate", "vehicleId") VALUES ('974548c5-ca10-4fc1-b443-e7b224160732', 'Brake Inspection', '2023-08-07T10:51:14.548Z', '8596c707-d585-439a-aad1-f0a8b4bf71ef');
INSERT INTO "service_milestone" ("id", "milestoneType", "dueDate", "vehicleId") VALUES ('86f71a4a-d068-4e1a-b683-39530e747ad9', 'Brake Inspection', '2024-10-08T09:31:09.025Z', '07534871-f49e-4b7a-b2b1-855141d4839b');
INSERT INTO "service_milestone" ("id", "milestoneType", "dueDate", "vehicleId") VALUES ('93967bce-15bf-4f35-b352-922c13c64741', 'Engine TuneUp', '2023-10-24T18:49:21.619Z', '8596c707-d585-439a-aad1-f0a8b4bf71ef');
INSERT INTO "service_milestone" ("id", "milestoneType", "dueDate", "vehicleId") VALUES ('719b1624-8c44-40d2-a61c-7246565cecb8', 'Transmission Check', '2025-02-11T07:34:32.543Z', '3c2f8ff3-9797-4b64-b23a-7fda395827ed');
INSERT INTO "service_milestone" ("id", "milestoneType", "dueDate", "vehicleId") VALUES ('1f0af800-9fb5-4269-a392-26592dc884ef', 'Transmission Check', '2024-08-12T23:02:50.572Z', '3c2f8ff3-9797-4b64-b23a-7fda395827ed');

INSERT INTO "fuel_record" ("id", "date", "fuelVolume", "vehicleId") VALUES ('82af0efb-1406-44c7-9568-16f8da009335', '2024-06-10T17:30:51.829Z', 816, '2d7fa795-b655-462e-b957-42cc8f2f41bf');
INSERT INTO "fuel_record" ("id", "date", "fuelVolume", "vehicleId") VALUES ('f32a9634-0624-41ef-b2e2-adbcf3ba3f41', '2025-04-05T22:00:33.698Z', 293, '2d7fa795-b655-462e-b957-42cc8f2f41bf');
INSERT INTO "fuel_record" ("id", "date", "fuelVolume", "vehicleId") VALUES ('7efbd72c-9755-4471-aca2-10e3d0a8505b', '2023-12-18T01:40:35.183Z', 659, '07534871-f49e-4b7a-b2b1-855141d4839b');
INSERT INTO "fuel_record" ("id", "date", "fuelVolume", "vehicleId") VALUES ('0336ea89-7788-4a19-8729-8ce6c89eb402', '2024-09-03T23:55:04.818Z', 147, '659530b7-0c0f-44a5-ac7a-27b08c39e57f');
INSERT INTO "fuel_record" ("id", "date", "fuelVolume", "vehicleId") VALUES ('5ab9d240-24b9-4931-b535-369a08326a60', '2024-04-28T06:02:08.918Z', 529, '39cfe9d9-ae3f-4aa5-ad9e-7a3a49e7734f');
INSERT INTO "fuel_record" ("id", "date", "fuelVolume", "vehicleId") VALUES ('9b7bfacb-53e8-4ee7-bede-a3f4a2283cff', '2024-02-02T15:32:00.305Z', 188, '2d7fa795-b655-462e-b957-42cc8f2f41bf');
INSERT INTO "fuel_record" ("id", "date", "fuelVolume", "vehicleId") VALUES ('45ae2fd5-51ee-494e-983e-c18a18fa4b82', '2023-10-13T21:27:31.131Z', 393, '7195f575-8c5d-4eff-b1be-01c1656e93f7');
INSERT INTO "fuel_record" ("id", "date", "fuelVolume", "vehicleId") VALUES ('40780101-28ca-4f17-95e3-2e0d7094b24e', '2023-09-29T05:44:09.238Z', 218, '39cfe9d9-ae3f-4aa5-ad9e-7a3a49e7734f');
INSERT INTO "fuel_record" ("id", "date", "fuelVolume", "vehicleId") VALUES ('7ad5c8b9-8b76-41e0-964a-7019515ab38f', '2024-04-17T19:19:05.469Z', 75, '7195f575-8c5d-4eff-b1be-01c1656e93f7');
INSERT INTO "fuel_record" ("id", "date", "fuelVolume", "vehicleId") VALUES ('f107245b-b682-4247-819c-7999ac04398b', '2024-05-23T11:09:04.744Z', 963, '07534871-f49e-4b7a-b2b1-855141d4839b');

INSERT INTO "maintenance_history" ("id", "completionDate", "details", "vehicleId", "taskId") VALUES ('a62149d3-0cff-4563-a8ab-4dc7e1c91863', '2024-05-27T11:33:24.394Z', 'Replaced brake pads and inspected brake lines', '07534871-f49e-4b7a-b2b1-855141d4839b', 'ad7d43dc-ea67-4666-a6ae-188afb885925');
INSERT INTO "maintenance_history" ("id", "completionDate", "details", "vehicleId", "taskId") VALUES ('225d1241-0eed-443e-a7a5-cbd894ce6480', '2024-08-31T07:18:02.525Z', 'Updated vehicle software and checked battery health', '07534871-f49e-4b7a-b2b1-855141d4839b', '006095c8-9a34-4e8d-b7d6-f1b330930e1e');
INSERT INTO "maintenance_history" ("id", "completionDate", "details", "vehicleId", "taskId") VALUES ('7a3828de-3a23-4b5d-add8-821f4760b389', '2023-09-17T15:57:41.733Z', 'Performed annual engine tuneup and oil change', '39cfe9d9-ae3f-4aa5-ad9e-7a3a49e7734f', '031fcf17-c93d-48dd-831f-e2ccbb091b0e');
INSERT INTO "maintenance_history" ("id", "completionDate", "details", "vehicleId", "taskId") VALUES ('22ba75d8-dcfb-4b1b-bd63-f7c070c53756', '2025-05-04T20:26:13.778Z', 'Performed annual engine tuneup and oil change', 'de7a2f61-2835-46d4-b44a-b3911f3a44cf', 'cb1e104f-24ca-42f7-86fc-dbd4e0e35a96');
INSERT INTO "maintenance_history" ("id", "completionDate", "details", "vehicleId", "taskId") VALUES ('ac65e779-1d72-4b59-bbc9-6381984870de', '2024-10-05T20:05:21.360Z', 'Replaced brake pads and inspected brake lines', '659530b7-0c0f-44a5-ac7a-27b08c39e57f', '23af9a4b-6bc5-418e-96d9-019f54920e63');
INSERT INTO "maintenance_history" ("id", "completionDate", "details", "vehicleId", "taskId") VALUES ('10c6df46-37c1-43d4-b592-71554fd09a27', '2025-02-21T09:10:51.446Z', 'Conducted tire rotation and alignment check', 'cc29d02e-b596-4f02-8639-e558c2260eea', '23af9a4b-6bc5-418e-96d9-019f54920e63');
INSERT INTO "maintenance_history" ("id", "completionDate", "details", "vehicleId", "taskId") VALUES ('d779c4fc-a6b6-47e9-858e-1bb5f27607dc', '2024-03-10T06:44:44.072Z', 'Conducted tire rotation and alignment check', 'd8947cc5-8c50-4856-ad1f-2ff652afc692', 'ad7d43dc-ea67-4666-a6ae-188afb885925');
INSERT INTO "maintenance_history" ("id", "completionDate", "details", "vehicleId", "taskId") VALUES ('071eca81-30ff-4e63-bf75-f66f84910b80', '2024-04-02T19:35:49.558Z', 'Conducted tire rotation and alignment check', 'de7a2f61-2835-46d4-b44a-b3911f3a44cf', '006095c8-9a34-4e8d-b7d6-f1b330930e1e');
INSERT INTO "maintenance_history" ("id", "completionDate", "details", "vehicleId", "taskId") VALUES ('ea91e60c-440f-423b-8ca1-ff6e3bf299fc', '2024-05-22T08:10:45.812Z', 'Conducted tire rotation and alignment check', '07534871-f49e-4b7a-b2b1-855141d4839b', '031fcf17-c93d-48dd-831f-e2ccbb091b0e');
INSERT INTO "maintenance_history" ("id", "completionDate", "details", "vehicleId", "taskId") VALUES ('0e4cd39a-32b4-4041-a176-b14e6cd63ac5', '2023-08-26T08:36:00.592Z', 'Performed annual engine tuneup and oil change', '659530b7-0c0f-44a5-ac7a-27b08c39e57f', 'f0a29740-60fd-40bc-b4db-88194c98a331');

INSERT INTO "event" ("id", "description", "startTime", "endTime") VALUES ('777c3e85-3460-4068-b377-111d83dc9251', 'Emergency Response Vehicle Readiness Check', '2024-03-20T22:14:20.299Z', '2024-08-16T18:40:31.214Z');
INSERT INTO "event" ("id", "description", "startTime", "endTime") VALUES ('cdb1f834-3808-4c17-9b65-1adf4b7b1501', 'Biannual Driver Training and Vehicle Functionality Test', '2024-10-08T02:14:56.315Z', '2024-10-06T16:57:54.316Z');
INSERT INTO "event" ("id", "description", "startTime", "endTime") VALUES ('8b8ee201-05e7-4f7c-b3b8-56c0896f7c65', 'Emergency Response Vehicle Readiness Check', '2023-10-04T08:57:52.976Z', '2024-03-28T05:14:34.803Z');
INSERT INTO "event" ("id", "description", "startTime", "endTime") VALUES ('15e8a636-6b96-4acb-85f2-0d48722c278b', 'Fleet Reallocation and Optimization for Peak Season', '2024-03-25T12:14:47.957Z', '2023-10-13T09:45:53.977Z');
INSERT INTO "event" ("id", "description", "startTime", "endTime") VALUES ('08a8a316-8a5c-4f00-8c31-c831cdc9c816', 'Annual Fleet Inspection and Maintenance Planning', '2023-08-17T03:15:42.311Z', '2024-08-02T14:33:49.624Z');
INSERT INTO "event" ("id", "description", "startTime", "endTime") VALUES ('063e7ccb-7b4d-4c69-b6d5-7bdd3da8a301', 'Quarterly Safety and Emissions Review', '2025-01-26T18:59:39.614Z', '2024-07-24T00:01:07.051Z');
INSERT INTO "event" ("id", "description", "startTime", "endTime") VALUES ('f449a4e8-df99-4eed-8767-c8bc248a6522', 'Emergency Response Vehicle Readiness Check', '2023-09-06T22:50:59.960Z', '2025-02-27T02:31:21.233Z');
INSERT INTO "event" ("id", "description", "startTime", "endTime") VALUES ('64991320-8f9a-41f9-b568-e268bb49f4b9', 'Quarterly Safety and Emissions Review', '2023-10-15T11:24:51.387Z', '2025-01-04T05:55:06.245Z');
INSERT INTO "event" ("id", "description", "startTime", "endTime") VALUES ('30c01b3a-f5c9-4729-9c2f-9bb19366912d', 'Annual Fleet Inspection and Maintenance Planning', '2023-06-21T22:21:45.855Z', '2024-01-25T06:19:28.515Z');
INSERT INTO "event" ("id", "description", "startTime", "endTime") VALUES ('7f0b5d2d-c301-4db0-a19c-ea4e7596f096', 'Biannual Driver Training and Vehicle Functionality Test', '2024-02-14T21:55:11.894Z', '2023-10-25T13:47:27.195Z');

INSERT INTO "vehicle_event" ("id", "vehicleId", "eventId") VALUES ('352b0456-c351-4b7f-b57e-b33da75c4505', '7195f575-8c5d-4eff-b1be-01c1656e93f7', '063e7ccb-7b4d-4c69-b6d5-7bdd3da8a301');
INSERT INTO "vehicle_event" ("id", "vehicleId", "eventId") VALUES ('5dbae6be-8259-47fd-8dee-40d07920f32a', '7195f575-8c5d-4eff-b1be-01c1656e93f7', '777c3e85-3460-4068-b377-111d83dc9251');
INSERT INTO "vehicle_event" ("id", "vehicleId", "eventId") VALUES ('6f58d117-5b95-488e-948f-aeac36ba10e1', '7195f575-8c5d-4eff-b1be-01c1656e93f7', '063e7ccb-7b4d-4c69-b6d5-7bdd3da8a301');
INSERT INTO "vehicle_event" ("id", "vehicleId", "eventId") VALUES ('2b3218cc-a690-4487-a69a-b839d2cbd47f', '39cfe9d9-ae3f-4aa5-ad9e-7a3a49e7734f', 'cdb1f834-3808-4c17-9b65-1adf4b7b1501');
INSERT INTO "vehicle_event" ("id", "vehicleId", "eventId") VALUES ('42f64d93-2794-43ac-b7a2-994065bb48f2', 'de7a2f61-2835-46d4-b44a-b3911f3a44cf', '7f0b5d2d-c301-4db0-a19c-ea4e7596f096');
INSERT INTO "vehicle_event" ("id", "vehicleId", "eventId") VALUES ('2abec19d-a624-46f3-90ab-1e13707d5849', '659530b7-0c0f-44a5-ac7a-27b08c39e57f', '7f0b5d2d-c301-4db0-a19c-ea4e7596f096');
INSERT INTO "vehicle_event" ("id", "vehicleId", "eventId") VALUES ('1a17dd3d-0e88-4fc1-a6b1-2a1414e51939', 'de7a2f61-2835-46d4-b44a-b3911f3a44cf', '777c3e85-3460-4068-b377-111d83dc9251');
INSERT INTO "vehicle_event" ("id", "vehicleId", "eventId") VALUES ('d8e633d8-c88d-464c-bdda-3dac0b35f35c', '8596c707-d585-439a-aad1-f0a8b4bf71ef', '15e8a636-6b96-4acb-85f2-0d48722c278b');
INSERT INTO "vehicle_event" ("id", "vehicleId", "eventId") VALUES ('876ac31e-aec9-4dda-8500-30d584fdb268', 'de7a2f61-2835-46d4-b44a-b3911f3a44cf', 'f449a4e8-df99-4eed-8767-c8bc248a6522');
INSERT INTO "vehicle_event" ("id", "vehicleId", "eventId") VALUES ('3029322d-24b7-48e4-9c8d-2d43a8a623e8', '7195f575-8c5d-4eff-b1be-01c1656e93f7', '30c01b3a-f5c9-4729-9c2f-9bb19366912d');

INSERT INTO "service_recommendation" ("id", "lastServiceDate", "recommendedServiceDate", "vehicleId") VALUES ('044c6d31-4146-4193-928c-b3728012ac7e', '2024-04-27T19:56:10.113Z', '2024-10-08T00:59:10.575Z', 'de7a2f61-2835-46d4-b44a-b3911f3a44cf');
INSERT INTO "service_recommendation" ("id", "lastServiceDate", "recommendedServiceDate", "vehicleId") VALUES ('dd4efccf-c02e-4075-a07a-942dbdfa8bb8', '2024-11-28T04:08:11.433Z', '2024-07-16T04:51:35.099Z', '7195f575-8c5d-4eff-b1be-01c1656e93f7');
INSERT INTO "service_recommendation" ("id", "lastServiceDate", "recommendedServiceDate", "vehicleId") VALUES ('c276ff9e-5b3f-4ab3-aa61-b8fafbfcdbec', '2024-01-11T00:08:18.773Z', '2024-01-06T08:42:26.109Z', '8596c707-d585-439a-aad1-f0a8b4bf71ef');
INSERT INTO "service_recommendation" ("id", "lastServiceDate", "recommendedServiceDate", "vehicleId") VALUES ('b8efdc37-bd0d-4c02-8348-4bd066ac7f9d', '2024-04-03T03:47:08.715Z', '2024-09-02T04:44:50.884Z', '3c2f8ff3-9797-4b64-b23a-7fda395827ed');
INSERT INTO "service_recommendation" ("id", "lastServiceDate", "recommendedServiceDate", "vehicleId") VALUES ('f93f1eaa-b2bc-4b15-9a1f-1c1e13df0943', '2023-09-08T10:37:29.061Z', '2024-09-21T07:29:40.810Z', '659530b7-0c0f-44a5-ac7a-27b08c39e57f');
INSERT INTO "service_recommendation" ("id", "lastServiceDate", "recommendedServiceDate", "vehicleId") VALUES ('0b433aaa-12c8-462d-a902-7bf41ee8d8e6', '2023-06-01T04:26:16.730Z', '2023-12-02T01:21:17.747Z', '7195f575-8c5d-4eff-b1be-01c1656e93f7');
INSERT INTO "service_recommendation" ("id", "lastServiceDate", "recommendedServiceDate", "vehicleId") VALUES ('f1365e4c-247b-4afe-9178-8b9eefb54f5a', '2025-03-14T23:50:16.849Z', '2023-06-24T12:08:35.604Z', '7195f575-8c5d-4eff-b1be-01c1656e93f7');
INSERT INTO "service_recommendation" ("id", "lastServiceDate", "recommendedServiceDate", "vehicleId") VALUES ('2918bb87-5b1e-4dd8-b94f-429db9527c1f', '2024-01-05T17:52:31.546Z', '2024-04-12T00:06:04.865Z', 'cc29d02e-b596-4f02-8639-e558c2260eea');
INSERT INTO "service_recommendation" ("id", "lastServiceDate", "recommendedServiceDate", "vehicleId") VALUES ('12b0f678-dc27-4892-b0d9-677493c86dd6', '2025-03-14T09:25:35.351Z', '2024-02-21T08:51:55.278Z', '3c2f8ff3-9797-4b64-b23a-7fda395827ed');
INSERT INTO "service_recommendation" ("id", "lastServiceDate", "recommendedServiceDate", "vehicleId") VALUES ('15c46945-b619-4de7-8f70-dbbd4fdd96b1', '2024-04-05T10:44:48.276Z', '2025-01-06T09:31:10.561Z', '07534871-f49e-4b7a-b2b1-855141d4839b');
    `,
      )
    } catch (error) {
      // ignore
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
