import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ServiceRecommendationDomainFacade } from './serviceRecommendation.domain.facade'
import { ServiceRecommendation } from './serviceRecommendation.model'

@Module({
  imports: [
    TypeOrmModule.forFeature([ServiceRecommendation]),
    DatabaseHelperModule,
  ],
  providers: [
    ServiceRecommendationDomainFacade,
    ServiceRecommendationDomainFacade,
  ],
  exports: [ServiceRecommendationDomainFacade],
})
export class ServiceRecommendationDomainModule {}
