import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { ServiceRecommendation } from './serviceRecommendation.model'

import { Vehicle } from '../../vehicle/domain'

@Injectable()
export class ServiceRecommendationDomainFacade {
  constructor(
    @InjectRepository(ServiceRecommendation)
    private repository: Repository<ServiceRecommendation>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(
    values: Partial<ServiceRecommendation>,
  ): Promise<ServiceRecommendation> {
    return this.repository.save(values)
  }

  async update(
    item: ServiceRecommendation,
    values: Partial<ServiceRecommendation>,
  ): Promise<ServiceRecommendation> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: ServiceRecommendation): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<ServiceRecommendation> = {},
  ): Promise<ServiceRecommendation[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<ServiceRecommendation> = {},
  ): Promise<ServiceRecommendation> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByVehicle(
    item: Vehicle,
    queryOptions: RequestHelper.QueryOptions<ServiceRecommendation> = {},
  ): Promise<ServiceRecommendation[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('vehicle')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        vehicleId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
