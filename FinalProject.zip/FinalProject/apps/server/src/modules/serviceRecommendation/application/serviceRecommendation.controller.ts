import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  ServiceRecommendation,
  ServiceRecommendationDomainFacade,
} from '@server/modules/serviceRecommendation/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ServiceRecommendationApplicationEvent } from './serviceRecommendation.application.event'
import {
  ServiceRecommendationCreateDto,
  ServiceRecommendationUpdateDto,
} from './serviceRecommendation.dto'

@Controller('/v1/serviceRecommendations')
export class ServiceRecommendationController {
  constructor(
    private eventService: EventService,
    private serviceRecommendationDomainFacade: ServiceRecommendationDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items =
      await this.serviceRecommendationDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: ServiceRecommendationCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.serviceRecommendationDomainFacade.create(body)

    await this.eventService.emit<ServiceRecommendationApplicationEvent.ServiceRecommendationCreated.Payload>(
      ServiceRecommendationApplicationEvent.ServiceRecommendationCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:serviceRecommendationId')
  async findOne(
    @Param('serviceRecommendationId') serviceRecommendationId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.serviceRecommendationDomainFacade.findOneByIdOrFail(
      serviceRecommendationId,
      queryOptions,
    )

    return item
  }

  @Patch('/:serviceRecommendationId')
  async update(
    @Param('serviceRecommendationId') serviceRecommendationId: string,
    @Body() body: ServiceRecommendationUpdateDto,
  ) {
    const item = await this.serviceRecommendationDomainFacade.findOneByIdOrFail(
      serviceRecommendationId,
    )

    const itemUpdated = await this.serviceRecommendationDomainFacade.update(
      item,
      body as Partial<ServiceRecommendation>,
    )
    return itemUpdated
  }

  @Delete('/:serviceRecommendationId')
  async delete(
    @Param('serviceRecommendationId') serviceRecommendationId: string,
  ) {
    const item = await this.serviceRecommendationDomainFacade.findOneByIdOrFail(
      serviceRecommendationId,
    )

    await this.serviceRecommendationDomainFacade.delete(item)

    return item
  }
}
