import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class ServiceRecommendationCreateDto {
  @IsString()
  @IsNotEmpty()
  lastServiceDate: string

  @IsString()
  @IsNotEmpty()
  recommendedServiceDate: string

  @IsString()
  @IsOptional()
  vehicleId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class ServiceRecommendationUpdateDto {
  @IsString()
  @IsOptional()
  lastServiceDate?: string

  @IsString()
  @IsOptional()
  recommendedServiceDate?: string

  @IsString()
  @IsOptional()
  vehicleId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
