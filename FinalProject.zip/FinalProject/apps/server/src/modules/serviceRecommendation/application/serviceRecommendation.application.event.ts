export namespace ServiceRecommendationApplicationEvent {
  export namespace ServiceRecommendationCreated {
    export const key =
      'serviceRecommendation.application.serviceRecommendation.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
