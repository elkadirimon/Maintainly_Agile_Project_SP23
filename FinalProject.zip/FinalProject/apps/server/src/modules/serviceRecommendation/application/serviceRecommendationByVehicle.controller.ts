import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ServiceRecommendationDomainFacade } from '@server/modules/serviceRecommendation/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ServiceRecommendationApplicationEvent } from './serviceRecommendation.application.event'
import { ServiceRecommendationCreateDto } from './serviceRecommendation.dto'

import { VehicleDomainFacade } from '../../vehicle/domain'

@Controller('/v1/vehicles')
export class ServiceRecommendationByVehicleController {
  constructor(
    private vehicleDomainFacade: VehicleDomainFacade,

    private serviceRecommendationDomainFacade: ServiceRecommendationDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/vehicle/:vehicleId/serviceRecommendations')
  async findManyVehicleId(
    @Param('vehicleId') vehicleId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.vehicleDomainFacade.findOneByIdOrFail(vehicleId)

    const items =
      await this.serviceRecommendationDomainFacade.findManyByVehicle(
        parent,
        queryOptions,
      )

    return items
  }

  @Post('/vehicle/:vehicleId/serviceRecommendations')
  async createByVehicleId(
    @Param('vehicleId') vehicleId: string,
    @Body() body: ServiceRecommendationCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, vehicleId }

    const item =
      await this.serviceRecommendationDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ServiceRecommendationApplicationEvent.ServiceRecommendationCreated.Payload>(
      ServiceRecommendationApplicationEvent.ServiceRecommendationCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
