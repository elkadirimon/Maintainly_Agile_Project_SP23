import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ServiceRecommendationDomainModule } from '../domain'
import { ServiceRecommendationController } from './serviceRecommendation.controller'

import { VehicleDomainModule } from '../../../modules/vehicle/domain'

import { ServiceRecommendationByVehicleController } from './serviceRecommendationByVehicle.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ServiceRecommendationDomainModule,

    VehicleDomainModule,
  ],
  controllers: [
    ServiceRecommendationController,

    ServiceRecommendationByVehicleController,
  ],
  providers: [],
})
export class ServiceRecommendationApplicationModule {}
