import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { VehicleDomainModule } from './vehicle/domain'

import { MaintenanceTaskDomainModule } from './maintenanceTask/domain'

import { ServiceMilestoneDomainModule } from './serviceMilestone/domain'

import { FuelRecordDomainModule } from './fuelRecord/domain'

import { MaintenanceHistoryDomainModule } from './maintenanceHistory/domain'

import { EventDomainModule } from './event/domain'

import { VehicleEventDomainModule } from './vehicleEvent/domain'

import { ServiceRecommendationDomainModule } from './serviceRecommendation/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

    VehicleDomainModule,

    MaintenanceTaskDomainModule,

    ServiceMilestoneDomainModule,

    FuelRecordDomainModule,

    MaintenanceHistoryDomainModule,

    EventDomainModule,

    VehicleEventDomainModule,

    ServiceRecommendationDomainModule,
  ],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
