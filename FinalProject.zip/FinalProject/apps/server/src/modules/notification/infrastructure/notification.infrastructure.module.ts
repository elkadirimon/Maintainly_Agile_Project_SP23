import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationVehicleSubscriber } from './subscribers/notification.vehicle.subscriber'

import { NotificationMaintenanceTaskSubscriber } from './subscribers/notification.maintenanceTask.subscriber'

import { NotificationServiceMilestoneSubscriber } from './subscribers/notification.serviceMilestone.subscriber'

import { NotificationFuelRecordSubscriber } from './subscribers/notification.fuelRecord.subscriber'

import { NotificationMaintenanceHistorySubscriber } from './subscribers/notification.maintenanceHistory.subscriber'

import { NotificationEventSubscriber } from './subscribers/notification.event.subscriber'

import { NotificationVehicleEventSubscriber } from './subscribers/notification.vehicleEvent.subscriber'

import { NotificationServiceRecommendationSubscriber } from './subscribers/notification.serviceRecommendation.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [
    NotificationVehicleSubscriber,

    NotificationMaintenanceTaskSubscriber,

    NotificationServiceMilestoneSubscriber,

    NotificationFuelRecordSubscriber,

    NotificationMaintenanceHistorySubscriber,

    NotificationEventSubscriber,

    NotificationVehicleEventSubscriber,

    NotificationServiceRecommendationSubscriber,
  ],
  exports: [],
})
export class NotificationInfrastructureModule {}
