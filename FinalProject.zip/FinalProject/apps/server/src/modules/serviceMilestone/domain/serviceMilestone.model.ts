import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Vehicle } from '../../../modules/vehicle/domain'

@Entity()
export class ServiceMilestone {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  milestoneType: string

  @Column({})
  dueDate: string

  @Column({})
  vehicleId: string

  @ManyToOne(() => Vehicle, parent => parent.serviceMilestones)
  @JoinColumn({ name: 'vehicleId' })
  vehicle?: Vehicle

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
