import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { ServiceMilestone } from './serviceMilestone.model'

import { Vehicle } from '../../vehicle/domain'

@Injectable()
export class ServiceMilestoneDomainFacade {
  constructor(
    @InjectRepository(ServiceMilestone)
    private repository: Repository<ServiceMilestone>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<ServiceMilestone>): Promise<ServiceMilestone> {
    return this.repository.save(values)
  }

  async update(
    item: ServiceMilestone,
    values: Partial<ServiceMilestone>,
  ): Promise<ServiceMilestone> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: ServiceMilestone): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<ServiceMilestone> = {},
  ): Promise<ServiceMilestone[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<ServiceMilestone> = {},
  ): Promise<ServiceMilestone> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByVehicle(
    item: Vehicle,
    queryOptions: RequestHelper.QueryOptions<ServiceMilestone> = {},
  ): Promise<ServiceMilestone[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('vehicle')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        vehicleId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
