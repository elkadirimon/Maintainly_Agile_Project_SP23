import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ServiceMilestoneDomainFacade } from './serviceMilestone.domain.facade'
import { ServiceMilestone } from './serviceMilestone.model'

@Module({
  imports: [TypeOrmModule.forFeature([ServiceMilestone]), DatabaseHelperModule],
  providers: [ServiceMilestoneDomainFacade, ServiceMilestoneDomainFacade],
  exports: [ServiceMilestoneDomainFacade],
})
export class ServiceMilestoneDomainModule {}
