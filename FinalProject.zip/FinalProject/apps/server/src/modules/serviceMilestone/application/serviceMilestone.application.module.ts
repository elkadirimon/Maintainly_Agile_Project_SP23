import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ServiceMilestoneDomainModule } from '../domain'
import { ServiceMilestoneController } from './serviceMilestone.controller'

import { VehicleDomainModule } from '../../../modules/vehicle/domain'

import { ServiceMilestoneByVehicleController } from './serviceMilestoneByVehicle.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ServiceMilestoneDomainModule,

    VehicleDomainModule,
  ],
  controllers: [
    ServiceMilestoneController,

    ServiceMilestoneByVehicleController,
  ],
  providers: [],
})
export class ServiceMilestoneApplicationModule {}
