import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ServiceMilestoneDomainFacade } from '@server/modules/serviceMilestone/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ServiceMilestoneApplicationEvent } from './serviceMilestone.application.event'
import { ServiceMilestoneCreateDto } from './serviceMilestone.dto'

import { VehicleDomainFacade } from '../../vehicle/domain'

@Controller('/v1/vehicles')
export class ServiceMilestoneByVehicleController {
  constructor(
    private vehicleDomainFacade: VehicleDomainFacade,

    private serviceMilestoneDomainFacade: ServiceMilestoneDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/vehicle/:vehicleId/serviceMilestones')
  async findManyVehicleId(
    @Param('vehicleId') vehicleId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.vehicleDomainFacade.findOneByIdOrFail(vehicleId)

    const items = await this.serviceMilestoneDomainFacade.findManyByVehicle(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/vehicle/:vehicleId/serviceMilestones')
  async createByVehicleId(
    @Param('vehicleId') vehicleId: string,
    @Body() body: ServiceMilestoneCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, vehicleId }

    const item = await this.serviceMilestoneDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ServiceMilestoneApplicationEvent.ServiceMilestoneCreated.Payload>(
      ServiceMilestoneApplicationEvent.ServiceMilestoneCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
