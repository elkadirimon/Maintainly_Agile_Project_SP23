import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  ServiceMilestone,
  ServiceMilestoneDomainFacade,
} from '@server/modules/serviceMilestone/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ServiceMilestoneApplicationEvent } from './serviceMilestone.application.event'
import {
  ServiceMilestoneCreateDto,
  ServiceMilestoneUpdateDto,
} from './serviceMilestone.dto'

@Controller('/v1/serviceMilestones')
export class ServiceMilestoneController {
  constructor(
    private eventService: EventService,
    private serviceMilestoneDomainFacade: ServiceMilestoneDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.serviceMilestoneDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: ServiceMilestoneCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.serviceMilestoneDomainFacade.create(body)

    await this.eventService.emit<ServiceMilestoneApplicationEvent.ServiceMilestoneCreated.Payload>(
      ServiceMilestoneApplicationEvent.ServiceMilestoneCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:serviceMilestoneId')
  async findOne(
    @Param('serviceMilestoneId') serviceMilestoneId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.serviceMilestoneDomainFacade.findOneByIdOrFail(
      serviceMilestoneId,
      queryOptions,
    )

    return item
  }

  @Patch('/:serviceMilestoneId')
  async update(
    @Param('serviceMilestoneId') serviceMilestoneId: string,
    @Body() body: ServiceMilestoneUpdateDto,
  ) {
    const item =
      await this.serviceMilestoneDomainFacade.findOneByIdOrFail(
        serviceMilestoneId,
      )

    const itemUpdated = await this.serviceMilestoneDomainFacade.update(
      item,
      body as Partial<ServiceMilestone>,
    )
    return itemUpdated
  }

  @Delete('/:serviceMilestoneId')
  async delete(@Param('serviceMilestoneId') serviceMilestoneId: string) {
    const item =
      await this.serviceMilestoneDomainFacade.findOneByIdOrFail(
        serviceMilestoneId,
      )

    await this.serviceMilestoneDomainFacade.delete(item)

    return item
  }
}
