export namespace ServiceMilestoneApplicationEvent {
  export namespace ServiceMilestoneCreated {
    export const key = 'serviceMilestone.application.serviceMilestone.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
