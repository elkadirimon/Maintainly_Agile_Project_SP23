import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { MaintenanceTask } from '../../../modules/maintenanceTask/domain'

import { ServiceMilestone } from '../../../modules/serviceMilestone/domain'

import { FuelRecord } from '../../../modules/fuelRecord/domain'

import { MaintenanceHistory } from '../../../modules/maintenanceHistory/domain'

import { VehicleEvent } from '../../../modules/vehicleEvent/domain'

import { ServiceRecommendation } from '../../../modules/serviceRecommendation/domain'

@Entity()
export class Vehicle {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  licensePlate: string

  @Column({})
  model: string

  @Column({})
  make: string

  @ColumnNumeric({ type: 'numeric' })
  year: number

  @OneToMany(() => MaintenanceTask, child => child.vehicle)
  maintenanceTasks?: MaintenanceTask[]

  @OneToMany(() => ServiceMilestone, child => child.vehicle)
  serviceMilestones?: ServiceMilestone[]

  @OneToMany(() => FuelRecord, child => child.vehicle)
  fuelRecords?: FuelRecord[]

  @OneToMany(() => MaintenanceHistory, child => child.vehicle)
  maintenanceHistorys?: MaintenanceHistory[]

  @OneToMany(() => VehicleEvent, child => child.vehicle)
  vehicleEvents?: VehicleEvent[]

  @OneToMany(() => ServiceRecommendation, child => child.vehicle)
  serviceRecommendations?: ServiceRecommendation[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
