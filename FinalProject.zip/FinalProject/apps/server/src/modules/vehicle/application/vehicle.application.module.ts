import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { VehicleDomainModule } from '../domain'
import { VehicleController } from './vehicle.controller'

@Module({
  imports: [AuthenticationDomainModule, VehicleDomainModule],
  controllers: [VehicleController],
  providers: [],
})
export class VehicleApplicationModule {}
