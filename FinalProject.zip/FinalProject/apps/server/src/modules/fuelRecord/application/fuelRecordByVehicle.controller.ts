import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { FuelRecordDomainFacade } from '@server/modules/fuelRecord/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { FuelRecordApplicationEvent } from './fuelRecord.application.event'
import { FuelRecordCreateDto } from './fuelRecord.dto'

import { VehicleDomainFacade } from '../../vehicle/domain'

@Controller('/v1/vehicles')
export class FuelRecordByVehicleController {
  constructor(
    private vehicleDomainFacade: VehicleDomainFacade,

    private fuelRecordDomainFacade: FuelRecordDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/vehicle/:vehicleId/fuelRecords')
  async findManyVehicleId(
    @Param('vehicleId') vehicleId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.vehicleDomainFacade.findOneByIdOrFail(vehicleId)

    const items = await this.fuelRecordDomainFacade.findManyByVehicle(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/vehicle/:vehicleId/fuelRecords')
  async createByVehicleId(
    @Param('vehicleId') vehicleId: string,
    @Body() body: FuelRecordCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, vehicleId }

    const item = await this.fuelRecordDomainFacade.create(valuesUpdated)

    await this.eventService.emit<FuelRecordApplicationEvent.FuelRecordCreated.Payload>(
      FuelRecordApplicationEvent.FuelRecordCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
