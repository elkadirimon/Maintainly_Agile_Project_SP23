import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { FuelRecordDomainModule } from '../domain'
import { FuelRecordController } from './fuelRecord.controller'

import { VehicleDomainModule } from '../../../modules/vehicle/domain'

import { FuelRecordByVehicleController } from './fuelRecordByVehicle.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    FuelRecordDomainModule,

    VehicleDomainModule,
  ],
  controllers: [FuelRecordController, FuelRecordByVehicleController],
  providers: [],
})
export class FuelRecordApplicationModule {}
