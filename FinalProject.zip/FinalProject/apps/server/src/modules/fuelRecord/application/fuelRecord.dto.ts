import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class FuelRecordCreateDto {
  @IsString()
  @IsNotEmpty()
  date: string

  @IsNumber()
  @IsNotEmpty()
  fuelVolume: number

  @IsString()
  @IsOptional()
  vehicleId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class FuelRecordUpdateDto {
  @IsString()
  @IsOptional()
  date?: string

  @IsNumber()
  @IsOptional()
  fuelVolume?: number

  @IsString()
  @IsOptional()
  vehicleId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
