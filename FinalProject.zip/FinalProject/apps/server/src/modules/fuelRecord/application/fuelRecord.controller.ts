import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  FuelRecord,
  FuelRecordDomainFacade,
} from '@server/modules/fuelRecord/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { FuelRecordApplicationEvent } from './fuelRecord.application.event'
import { FuelRecordCreateDto, FuelRecordUpdateDto } from './fuelRecord.dto'

@Controller('/v1/fuelRecords')
export class FuelRecordController {
  constructor(
    private eventService: EventService,
    private fuelRecordDomainFacade: FuelRecordDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.fuelRecordDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: FuelRecordCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.fuelRecordDomainFacade.create(body)

    await this.eventService.emit<FuelRecordApplicationEvent.FuelRecordCreated.Payload>(
      FuelRecordApplicationEvent.FuelRecordCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:fuelRecordId')
  async findOne(
    @Param('fuelRecordId') fuelRecordId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.fuelRecordDomainFacade.findOneByIdOrFail(
      fuelRecordId,
      queryOptions,
    )

    return item
  }

  @Patch('/:fuelRecordId')
  async update(
    @Param('fuelRecordId') fuelRecordId: string,
    @Body() body: FuelRecordUpdateDto,
  ) {
    const item =
      await this.fuelRecordDomainFacade.findOneByIdOrFail(fuelRecordId)

    const itemUpdated = await this.fuelRecordDomainFacade.update(
      item,
      body as Partial<FuelRecord>,
    )
    return itemUpdated
  }

  @Delete('/:fuelRecordId')
  async delete(@Param('fuelRecordId') fuelRecordId: string) {
    const item =
      await this.fuelRecordDomainFacade.findOneByIdOrFail(fuelRecordId)

    await this.fuelRecordDomainFacade.delete(item)

    return item
  }
}
