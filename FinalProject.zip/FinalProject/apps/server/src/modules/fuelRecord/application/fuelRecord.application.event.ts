export namespace FuelRecordApplicationEvent {
  export namespace FuelRecordCreated {
    export const key = 'fuelRecord.application.fuelRecord.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
