import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { FuelRecordDomainFacade } from './fuelRecord.domain.facade'
import { FuelRecord } from './fuelRecord.model'

@Module({
  imports: [TypeOrmModule.forFeature([FuelRecord]), DatabaseHelperModule],
  providers: [FuelRecordDomainFacade, FuelRecordDomainFacade],
  exports: [FuelRecordDomainFacade],
})
export class FuelRecordDomainModule {}
