import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Vehicle } from '../../../modules/vehicle/domain'

@Entity()
export class FuelRecord {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  date: string

  @ColumnNumeric({ type: 'numeric' })
  fuelVolume: number

  @Column({})
  vehicleId: string

  @ManyToOne(() => Vehicle, parent => parent.fuelRecords)
  @JoinColumn({ name: 'vehicleId' })
  vehicle?: Vehicle

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
