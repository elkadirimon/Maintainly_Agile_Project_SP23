import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  VehicleEvent,
  VehicleEventDomainFacade,
} from '@server/modules/vehicleEvent/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { VehicleEventApplicationEvent } from './vehicleEvent.application.event'
import {
  VehicleEventCreateDto,
  VehicleEventUpdateDto,
} from './vehicleEvent.dto'

@Controller('/v1/vehicleEvents')
export class VehicleEventController {
  constructor(
    private eventService: EventService,
    private vehicleEventDomainFacade: VehicleEventDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.vehicleEventDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: VehicleEventCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.vehicleEventDomainFacade.create(body)

    await this.eventService.emit<VehicleEventApplicationEvent.VehicleEventCreated.Payload>(
      VehicleEventApplicationEvent.VehicleEventCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:vehicleEventId')
  async findOne(
    @Param('vehicleEventId') vehicleEventId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.vehicleEventDomainFacade.findOneByIdOrFail(
      vehicleEventId,
      queryOptions,
    )

    return item
  }

  @Patch('/:vehicleEventId')
  async update(
    @Param('vehicleEventId') vehicleEventId: string,
    @Body() body: VehicleEventUpdateDto,
  ) {
    const item =
      await this.vehicleEventDomainFacade.findOneByIdOrFail(vehicleEventId)

    const itemUpdated = await this.vehicleEventDomainFacade.update(
      item,
      body as Partial<VehicleEvent>,
    )
    return itemUpdated
  }

  @Delete('/:vehicleEventId')
  async delete(@Param('vehicleEventId') vehicleEventId: string) {
    const item =
      await this.vehicleEventDomainFacade.findOneByIdOrFail(vehicleEventId)

    await this.vehicleEventDomainFacade.delete(item)

    return item
  }
}
