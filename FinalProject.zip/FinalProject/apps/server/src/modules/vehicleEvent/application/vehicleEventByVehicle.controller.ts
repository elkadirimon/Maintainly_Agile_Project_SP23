import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { VehicleEventDomainFacade } from '@server/modules/vehicleEvent/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { VehicleEventApplicationEvent } from './vehicleEvent.application.event'
import { VehicleEventCreateDto } from './vehicleEvent.dto'

import { VehicleDomainFacade } from '../../vehicle/domain'

@Controller('/v1/vehicles')
export class VehicleEventByVehicleController {
  constructor(
    private vehicleDomainFacade: VehicleDomainFacade,

    private vehicleEventDomainFacade: VehicleEventDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/vehicle/:vehicleId/vehicleEvents')
  async findManyVehicleId(
    @Param('vehicleId') vehicleId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.vehicleDomainFacade.findOneByIdOrFail(vehicleId)

    const items = await this.vehicleEventDomainFacade.findManyByVehicle(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/vehicle/:vehicleId/vehicleEvents')
  async createByVehicleId(
    @Param('vehicleId') vehicleId: string,
    @Body() body: VehicleEventCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, vehicleId }

    const item = await this.vehicleEventDomainFacade.create(valuesUpdated)

    await this.eventService.emit<VehicleEventApplicationEvent.VehicleEventCreated.Payload>(
      VehicleEventApplicationEvent.VehicleEventCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
