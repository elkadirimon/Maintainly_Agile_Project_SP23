export namespace VehicleEventApplicationEvent {
  export namespace VehicleEventCreated {
    export const key = 'vehicleEvent.application.vehicleEvent.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
