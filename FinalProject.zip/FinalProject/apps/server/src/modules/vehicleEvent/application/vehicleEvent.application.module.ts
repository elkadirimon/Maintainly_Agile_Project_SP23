import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { VehicleEventDomainModule } from '../domain'
import { VehicleEventController } from './vehicleEvent.controller'

import { VehicleDomainModule } from '../../../modules/vehicle/domain'

import { VehicleEventByVehicleController } from './vehicleEventByVehicle.controller'

import { EventDomainModule } from '../../../modules/event/domain'

import { VehicleEventByEventController } from './vehicleEventByEvent.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    VehicleEventDomainModule,

    VehicleDomainModule,

    EventDomainModule,
  ],
  controllers: [
    VehicleEventController,

    VehicleEventByVehicleController,

    VehicleEventByEventController,
  ],
  providers: [],
})
export class VehicleEventApplicationModule {}
