import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class VehicleEventCreateDto {
  @IsString()
  @IsOptional()
  vehicleId?: string

  @IsString()
  @IsOptional()
  eventId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class VehicleEventUpdateDto {
  @IsString()
  @IsOptional()
  vehicleId?: string

  @IsString()
  @IsOptional()
  eventId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
