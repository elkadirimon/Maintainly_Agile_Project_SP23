import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Vehicle } from '../../../modules/vehicle/domain'

import { Event } from '../../../modules/event/domain'

@Entity()
export class VehicleEvent {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  vehicleId: string

  @ManyToOne(() => Vehicle, parent => parent.vehicleEvents)
  @JoinColumn({ name: 'vehicleId' })
  vehicle?: Vehicle

  @Column({})
  eventId: string

  @ManyToOne(() => Event, parent => parent.vehicleEvents)
  @JoinColumn({ name: 'eventId' })
  event?: Event

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
