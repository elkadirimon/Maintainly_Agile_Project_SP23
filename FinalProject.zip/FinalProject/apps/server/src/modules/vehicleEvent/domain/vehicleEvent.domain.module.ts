import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { VehicleEventDomainFacade } from './vehicleEvent.domain.facade'
import { VehicleEvent } from './vehicleEvent.model'

@Module({
  imports: [TypeOrmModule.forFeature([VehicleEvent]), DatabaseHelperModule],
  providers: [VehicleEventDomainFacade, VehicleEventDomainFacade],
  exports: [VehicleEventDomainFacade],
})
export class VehicleEventDomainModule {}
