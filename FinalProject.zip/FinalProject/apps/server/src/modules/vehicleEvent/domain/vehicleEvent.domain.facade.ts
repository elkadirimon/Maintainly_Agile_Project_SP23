import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { VehicleEvent } from './vehicleEvent.model'

import { Vehicle } from '../../vehicle/domain'

import { Event } from '../../event/domain'

@Injectable()
export class VehicleEventDomainFacade {
  constructor(
    @InjectRepository(VehicleEvent)
    private repository: Repository<VehicleEvent>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<VehicleEvent>): Promise<VehicleEvent> {
    return this.repository.save(values)
  }

  async update(
    item: VehicleEvent,
    values: Partial<VehicleEvent>,
  ): Promise<VehicleEvent> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: VehicleEvent): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<VehicleEvent> = {},
  ): Promise<VehicleEvent[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<VehicleEvent> = {},
  ): Promise<VehicleEvent> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByVehicle(
    item: Vehicle,
    queryOptions: RequestHelper.QueryOptions<VehicleEvent> = {},
  ): Promise<VehicleEvent[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('vehicle')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        vehicleId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByEvent(
    item: Event,
    queryOptions: RequestHelper.QueryOptions<VehicleEvent> = {},
  ): Promise<VehicleEvent[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('event')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        eventId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
