import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { MaintenanceTaskDomainFacade } from './maintenanceTask.domain.facade'
import { MaintenanceTask } from './maintenanceTask.model'

@Module({
  imports: [TypeOrmModule.forFeature([MaintenanceTask]), DatabaseHelperModule],
  providers: [MaintenanceTaskDomainFacade, MaintenanceTaskDomainFacade],
  exports: [MaintenanceTaskDomainFacade],
})
export class MaintenanceTaskDomainModule {}
