import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Vehicle } from '../../../modules/vehicle/domain'

import { MaintenanceHistory } from '../../../modules/maintenanceHistory/domain'

@Entity()
export class MaintenanceTask {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  description: string

  @Column({})
  dueDate: string

  @Column({})
  status: string

  @Column({})
  vehicleId: string

  @ManyToOne(() => Vehicle, parent => parent.maintenanceTasks)
  @JoinColumn({ name: 'vehicleId' })
  vehicle?: Vehicle

  @OneToMany(() => MaintenanceHistory, child => child.task)
  maintenanceHistorysAsTask?: MaintenanceHistory[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
