export namespace MaintenanceTaskApplicationEvent {
  export namespace MaintenanceTaskCreated {
    export const key = 'maintenanceTask.application.maintenanceTask.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
