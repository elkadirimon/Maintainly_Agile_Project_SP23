import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { MaintenanceTaskDomainModule } from '../domain'
import { MaintenanceTaskController } from './maintenanceTask.controller'

import { VehicleDomainModule } from '../../../modules/vehicle/domain'

import { MaintenanceTaskByVehicleController } from './maintenanceTaskByVehicle.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    MaintenanceTaskDomainModule,

    VehicleDomainModule,
  ],
  controllers: [MaintenanceTaskController, MaintenanceTaskByVehicleController],
  providers: [],
})
export class MaintenanceTaskApplicationModule {}
