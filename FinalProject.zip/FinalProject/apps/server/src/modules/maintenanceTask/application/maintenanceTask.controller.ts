import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  MaintenanceTask,
  MaintenanceTaskDomainFacade,
} from '@server/modules/maintenanceTask/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { MaintenanceTaskApplicationEvent } from './maintenanceTask.application.event'
import {
  MaintenanceTaskCreateDto,
  MaintenanceTaskUpdateDto,
} from './maintenanceTask.dto'

@Controller('/v1/maintenanceTasks')
export class MaintenanceTaskController {
  constructor(
    private eventService: EventService,
    private maintenanceTaskDomainFacade: MaintenanceTaskDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.maintenanceTaskDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: MaintenanceTaskCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.maintenanceTaskDomainFacade.create(body)

    await this.eventService.emit<MaintenanceTaskApplicationEvent.MaintenanceTaskCreated.Payload>(
      MaintenanceTaskApplicationEvent.MaintenanceTaskCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:maintenanceTaskId')
  async findOne(
    @Param('maintenanceTaskId') maintenanceTaskId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.maintenanceTaskDomainFacade.findOneByIdOrFail(
      maintenanceTaskId,
      queryOptions,
    )

    return item
  }

  @Patch('/:maintenanceTaskId')
  async update(
    @Param('maintenanceTaskId') maintenanceTaskId: string,
    @Body() body: MaintenanceTaskUpdateDto,
  ) {
    const item =
      await this.maintenanceTaskDomainFacade.findOneByIdOrFail(
        maintenanceTaskId,
      )

    const itemUpdated = await this.maintenanceTaskDomainFacade.update(
      item,
      body as Partial<MaintenanceTask>,
    )
    return itemUpdated
  }

  @Delete('/:maintenanceTaskId')
  async delete(@Param('maintenanceTaskId') maintenanceTaskId: string) {
    const item =
      await this.maintenanceTaskDomainFacade.findOneByIdOrFail(
        maintenanceTaskId,
      )

    await this.maintenanceTaskDomainFacade.delete(item)

    return item
  }
}
