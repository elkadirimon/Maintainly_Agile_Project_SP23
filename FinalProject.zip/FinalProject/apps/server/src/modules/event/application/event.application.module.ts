import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { EventDomainModule } from '../domain'
import { EventController } from './event.controller'

@Module({
  imports: [AuthenticationDomainModule, EventDomainModule],
  controllers: [EventController],
  providers: [],
})
export class EventApplicationModule {}
