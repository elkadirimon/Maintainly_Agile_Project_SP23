import { Module } from '@nestjs/common'
import { AuthenticationApplicationModule } from './authentication/application'
import { AuthorizationApplicationModule } from './authorization/application'
import { UserApplicationModule } from './user/application'

import { VehicleApplicationModule } from './vehicle/application'

import { MaintenanceTaskApplicationModule } from './maintenanceTask/application'

import { ServiceMilestoneApplicationModule } from './serviceMilestone/application'

import { FuelRecordApplicationModule } from './fuelRecord/application'

import { MaintenanceHistoryApplicationModule } from './maintenanceHistory/application'

import { EventApplicationModule } from './event/application'

import { VehicleEventApplicationModule } from './vehicleEvent/application'

import { ServiceRecommendationApplicationModule } from './serviceRecommendation/application'

import { AiApplicationModule } from './ai/application/ai.application.module'
import { NotificationApplicationModule } from './notification/application/notification.application.module'
import { UploadApplicationModule } from './upload/application/upload.application.module'

@Module({
  imports: [
    AuthenticationApplicationModule,
    UserApplicationModule,
    AuthorizationApplicationModule,
    NotificationApplicationModule,
    AiApplicationModule,
    UploadApplicationModule,

    VehicleApplicationModule,

    MaintenanceTaskApplicationModule,

    ServiceMilestoneApplicationModule,

    FuelRecordApplicationModule,

    MaintenanceHistoryApplicationModule,

    EventApplicationModule,

    VehicleEventApplicationModule,

    ServiceRecommendationApplicationModule,
  ],
  controllers: [],
  providers: [],
})
export class AppApplicationModule {}
