import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { MaintenanceHistory } from './maintenanceHistory.model'

import { Vehicle } from '../../vehicle/domain'

import { MaintenanceTask } from '../../maintenanceTask/domain'

@Injectable()
export class MaintenanceHistoryDomainFacade {
  constructor(
    @InjectRepository(MaintenanceHistory)
    private repository: Repository<MaintenanceHistory>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(
    values: Partial<MaintenanceHistory>,
  ): Promise<MaintenanceHistory> {
    return this.repository.save(values)
  }

  async update(
    item: MaintenanceHistory,
    values: Partial<MaintenanceHistory>,
  ): Promise<MaintenanceHistory> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: MaintenanceHistory): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<MaintenanceHistory> = {},
  ): Promise<MaintenanceHistory[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<MaintenanceHistory> = {},
  ): Promise<MaintenanceHistory> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByVehicle(
    item: Vehicle,
    queryOptions: RequestHelper.QueryOptions<MaintenanceHistory> = {},
  ): Promise<MaintenanceHistory[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('vehicle')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        vehicleId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByTask(
    item: MaintenanceTask,
    queryOptions: RequestHelper.QueryOptions<MaintenanceHistory> = {},
  ): Promise<MaintenanceHistory[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('task')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        taskId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
