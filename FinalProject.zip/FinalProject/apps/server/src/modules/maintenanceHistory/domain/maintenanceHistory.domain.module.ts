import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { MaintenanceHistoryDomainFacade } from './maintenanceHistory.domain.facade'
import { MaintenanceHistory } from './maintenanceHistory.model'

@Module({
  imports: [
    TypeOrmModule.forFeature([MaintenanceHistory]),
    DatabaseHelperModule,
  ],
  providers: [MaintenanceHistoryDomainFacade, MaintenanceHistoryDomainFacade],
  exports: [MaintenanceHistoryDomainFacade],
})
export class MaintenanceHistoryDomainModule {}
