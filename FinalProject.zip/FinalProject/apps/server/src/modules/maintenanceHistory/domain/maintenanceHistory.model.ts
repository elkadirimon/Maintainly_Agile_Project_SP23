import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Vehicle } from '../../../modules/vehicle/domain'

import { MaintenanceTask } from '../../../modules/maintenanceTask/domain'

@Entity()
export class MaintenanceHistory {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  completionDate: string

  @Column({})
  details: string

  @Column({})
  vehicleId: string

  @ManyToOne(() => Vehicle, parent => parent.maintenanceHistorys)
  @JoinColumn({ name: 'vehicleId' })
  vehicle?: Vehicle

  @Column({})
  taskId: string

  @ManyToOne(() => MaintenanceTask, parent => parent.maintenanceHistorysAsTask)
  @JoinColumn({ name: 'taskId' })
  task?: MaintenanceTask

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
