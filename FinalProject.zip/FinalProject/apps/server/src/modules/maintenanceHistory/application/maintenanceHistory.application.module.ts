import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { MaintenanceHistoryDomainModule } from '../domain'
import { MaintenanceHistoryController } from './maintenanceHistory.controller'

import { VehicleDomainModule } from '../../../modules/vehicle/domain'

import { MaintenanceHistoryByVehicleController } from './maintenanceHistoryByVehicle.controller'

import { MaintenanceTaskDomainModule } from '../../../modules/maintenanceTask/domain'

import { MaintenanceHistoryByMaintenanceTaskController } from './maintenanceHistoryByMaintenanceTask.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    MaintenanceHistoryDomainModule,

    VehicleDomainModule,

    MaintenanceTaskDomainModule,
  ],
  controllers: [
    MaintenanceHistoryController,

    MaintenanceHistoryByVehicleController,

    MaintenanceHistoryByMaintenanceTaskController,
  ],
  providers: [],
})
export class MaintenanceHistoryApplicationModule {}
