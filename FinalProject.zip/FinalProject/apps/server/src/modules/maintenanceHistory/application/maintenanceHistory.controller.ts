import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  MaintenanceHistory,
  MaintenanceHistoryDomainFacade,
} from '@server/modules/maintenanceHistory/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { MaintenanceHistoryApplicationEvent } from './maintenanceHistory.application.event'
import {
  MaintenanceHistoryCreateDto,
  MaintenanceHistoryUpdateDto,
} from './maintenanceHistory.dto'

@Controller('/v1/maintenanceHistorys')
export class MaintenanceHistoryController {
  constructor(
    private eventService: EventService,
    private maintenanceHistoryDomainFacade: MaintenanceHistoryDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items =
      await this.maintenanceHistoryDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(
    @Body() body: MaintenanceHistoryCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.maintenanceHistoryDomainFacade.create(body)

    await this.eventService.emit<MaintenanceHistoryApplicationEvent.MaintenanceHistoryCreated.Payload>(
      MaintenanceHistoryApplicationEvent.MaintenanceHistoryCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:maintenanceHistoryId')
  async findOne(
    @Param('maintenanceHistoryId') maintenanceHistoryId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.maintenanceHistoryDomainFacade.findOneByIdOrFail(
      maintenanceHistoryId,
      queryOptions,
    )

    return item
  }

  @Patch('/:maintenanceHistoryId')
  async update(
    @Param('maintenanceHistoryId') maintenanceHistoryId: string,
    @Body() body: MaintenanceHistoryUpdateDto,
  ) {
    const item =
      await this.maintenanceHistoryDomainFacade.findOneByIdOrFail(
        maintenanceHistoryId,
      )

    const itemUpdated = await this.maintenanceHistoryDomainFacade.update(
      item,
      body as Partial<MaintenanceHistory>,
    )
    return itemUpdated
  }

  @Delete('/:maintenanceHistoryId')
  async delete(@Param('maintenanceHistoryId') maintenanceHistoryId: string) {
    const item =
      await this.maintenanceHistoryDomainFacade.findOneByIdOrFail(
        maintenanceHistoryId,
      )

    await this.maintenanceHistoryDomainFacade.delete(item)

    return item
  }
}
