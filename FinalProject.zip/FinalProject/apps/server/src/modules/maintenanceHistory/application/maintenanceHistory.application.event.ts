export namespace MaintenanceHistoryApplicationEvent {
  export namespace MaintenanceHistoryCreated {
    export const key =
      'maintenanceHistory.application.maintenanceHistory.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
