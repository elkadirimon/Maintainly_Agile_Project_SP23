import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { MaintenanceHistoryDomainFacade } from '@server/modules/maintenanceHistory/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { MaintenanceHistoryApplicationEvent } from './maintenanceHistory.application.event'
import { MaintenanceHistoryCreateDto } from './maintenanceHistory.dto'

import { VehicleDomainFacade } from '../../vehicle/domain'

@Controller('/v1/vehicles')
export class MaintenanceHistoryByVehicleController {
  constructor(
    private vehicleDomainFacade: VehicleDomainFacade,

    private maintenanceHistoryDomainFacade: MaintenanceHistoryDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/vehicle/:vehicleId/maintenanceHistorys')
  async findManyVehicleId(
    @Param('vehicleId') vehicleId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.vehicleDomainFacade.findOneByIdOrFail(vehicleId)

    const items = await this.maintenanceHistoryDomainFacade.findManyByVehicle(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/vehicle/:vehicleId/maintenanceHistorys')
  async createByVehicleId(
    @Param('vehicleId') vehicleId: string,
    @Body() body: MaintenanceHistoryCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, vehicleId }

    const item = await this.maintenanceHistoryDomainFacade.create(valuesUpdated)

    await this.eventService.emit<MaintenanceHistoryApplicationEvent.MaintenanceHistoryCreated.Payload>(
      MaintenanceHistoryApplicationEvent.MaintenanceHistoryCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
