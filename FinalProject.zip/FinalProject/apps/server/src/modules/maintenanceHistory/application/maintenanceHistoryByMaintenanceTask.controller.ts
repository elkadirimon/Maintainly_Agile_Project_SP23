import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { MaintenanceHistoryDomainFacade } from '@server/modules/maintenanceHistory/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { MaintenanceHistoryApplicationEvent } from './maintenanceHistory.application.event'
import { MaintenanceHistoryCreateDto } from './maintenanceHistory.dto'

import { MaintenanceTaskDomainFacade } from '../../maintenanceTask/domain'

@Controller('/v1/maintenanceTasks')
export class MaintenanceHistoryByMaintenanceTaskController {
  constructor(
    private maintenanceTaskDomainFacade: MaintenanceTaskDomainFacade,

    private maintenanceHistoryDomainFacade: MaintenanceHistoryDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/task/:taskId/maintenanceHistorys')
  async findManyTaskId(
    @Param('taskId') taskId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent =
      await this.maintenanceTaskDomainFacade.findOneByIdOrFail(taskId)

    const items = await this.maintenanceHistoryDomainFacade.findManyByTask(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/task/:taskId/maintenanceHistorys')
  async createByTaskId(
    @Param('taskId') taskId: string,
    @Body() body: MaintenanceHistoryCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, taskId }

    const item = await this.maintenanceHistoryDomainFacade.create(valuesUpdated)

    await this.eventService.emit<MaintenanceHistoryApplicationEvent.MaintenanceHistoryCreated.Payload>(
      MaintenanceHistoryApplicationEvent.MaintenanceHistoryCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
