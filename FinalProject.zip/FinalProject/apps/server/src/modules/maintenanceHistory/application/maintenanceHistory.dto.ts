import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class MaintenanceHistoryCreateDto {
  @IsString()
  @IsNotEmpty()
  completionDate: string

  @IsString()
  @IsNotEmpty()
  details: string

  @IsString()
  @IsOptional()
  vehicleId?: string

  @IsString()
  @IsOptional()
  taskId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class MaintenanceHistoryUpdateDto {
  @IsString()
  @IsOptional()
  completionDate?: string

  @IsString()
  @IsOptional()
  details?: string

  @IsString()
  @IsOptional()
  vehicleId?: string

  @IsString()
  @IsOptional()
  taskId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
